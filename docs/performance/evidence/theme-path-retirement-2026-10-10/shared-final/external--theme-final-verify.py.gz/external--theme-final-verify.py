import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/Users/frankorz/Documents/projects/rust/merman/.worktrees/theme-ownership-performance')
EXPERIMENT = ROOT / 'target/bench/experiments/theme-retirement-20261010-3a11f46ba'
SOURCE = EXPERIMENT / 'candidate-src'
OUTPUT = EXPERIMENT / 'verification/shared-final'
OUTPUT.mkdir(exist_ok=True)
ENV = dict(os.environ, CARGO_BUILD_JOBS='2', CARGO_TARGET_DIR=str(ROOT / 'target'), PLAYWRIGHT_PORT='4189')
RECEIPTS = json.loads((OUTPUT / 'execution.json').read_text())

def run(name, command):
    print(name, flush=True)
    log = OUTPUT / (name + '.log')
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=SOURCE, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    RECEIPTS.append({'name': name, 'command': command, 'exit': result.returncode, 'log': str(log)})
    (OUTPUT / 'execution.json').write_text(json.dumps(RECEIPTS, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError(f'{name} failed; see {log}')

npm = ['npx', '--yes', 'npm@12.0.2']
run('playground-build', [*npm, '--prefix', 'playground', 'run', 'build'])
run('browser-typecheck', [*npm, '--prefix', 'playground/tests', 'run', 'typecheck'])
run('browser-themes', [*npm, '--prefix', 'playground/tests', 'run', 'test:desktop', '--', 'theme-cyberpunk.spec.ts', 'custom-theme.spec.ts', 'theme-initialization.spec.ts', 'theme-design-scope.spec.ts', 'theme-text-surface.smoke.spec.ts', 'viewport-workspace.spec.ts', 'root-viewport-oracle.spec.ts'])
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True).strip()
print('Shared implementation consumer, corpus and browser checks passed.', flush=True)
