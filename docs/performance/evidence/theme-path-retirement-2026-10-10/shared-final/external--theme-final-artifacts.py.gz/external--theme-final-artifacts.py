import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path('/Users/frankorz/Documents/projects/rust/merman/.worktrees/theme-ownership-performance')
EXPERIMENT = ROOT / 'target/bench/experiments/theme-retirement-20261010-3a11f46ba'
SOURCE = EXPERIMENT / 'candidate-src'
OUTPUT = EXPERIMENT / 'size/final-artifacts'
OUTPUT.mkdir(exist_ok=True)
ENV = os.environ.copy()
ENV['CARGO_BUILD_JOBS'] = '2'
ENV['CARGO_TARGET_DIR'] = str(ROOT / 'target')
ENV['PATH'] = str(ROOT / 'target/bench/tools/binaryen-version_131/binaryen-version_131/bin') + os.pathsep + ENV['PATH']
RECEIPTS = []


def run(name, command):
    log = OUTPUT / (name + '.log')
    print(name, flush=True)
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=SOURCE, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    RECEIPTS.append({'name': name, 'command': command, 'source': str(SOURCE), 'exit': result.returncode, 'log': log.name})
    (OUTPUT / 'execution.json').write_text(json.dumps(RECEIPTS, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError(f'{name} failed: {log}')
    return log


expected = 'dd79ca584de4bb8b0045f572302d2ba355ce1958'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == expected
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True).strip()
run('web-build', ['npm', 'run', 'build', '--prefix', 'platforms/web'])
run('web-smoke', ['npm', 'run', 'smoke', '--prefix', 'platforms/web'])
run('source-xtask', ['cargo', 'build', '--locked', '--release', '-p', 'xtask'])
xtask = str(OUTPUT / 'xtask')
shutil.copy2(ROOT / 'target/release/xtask', xtask)
profiles = ['web-analysis', 'web-ascii', 'web-editor', 'web-full', 'web-render', 'typst-wasm']
run('dependency-closures', ['python3', 'scripts/verify_artifact_dependency_closures.py', *[value for profile in profiles for value in ('--profile', profile)]])
for name, features in [('typst-minimal', []), ('typst-complete', ['--features', 'all-diagrams,analysis,layout-cytoscape,layout-elk,svg'])]:
    run(name, ['cargo', 'nextest', 'run', '--locked', '-p', 'merman-typst-plugin', '--no-default-features', *features])
typst_out = str(OUTPUT / 'typst-package')
run('typst-build', [xtask, 'build-typst-package', '--profile', 'publish', '--out', typst_out])
run('typst-smoke', [xtask, 'typst-package-smoke', '--profile', 'publish', '--out', typst_out, '--skip-wasm-build', '--keep-artifacts', '--typst', str(ROOT / 'target/bench/tools/typst-0.15.0/typst-aarch64-apple-darwin/typst')])
packaged_typst = list(Path(typst_out).rglob('merman_typst_plugin.wasm'))
assert len(packaged_typst) == 1, packaged_typst
typst_package = packaged_typst[0]
(OUTPUT / 'typst-package-identity.json').write_text(json.dumps({'path': str(typst_package), 'bytes': typst_package.stat().st_size, 'sha256': hashlib.sha256(typst_package.read_bytes()).hexdigest()}, indent=2) + '\n')
# Preserve the exact owner-produced stripped files before its temporary directory
# is removed. The forwarding executable leaves tool arguments and bytes intact.
real_wasm_tools = shutil.which('wasm-tools', path=ENV['PATH'])
assert real_wasm_tools
capture = OUTPUT / 'measurement-stripped'
capture.mkdir(exist_ok=True)
forwarders = OUTPUT / 'measurement-tools'
forwarders.mkdir(exist_ok=True)
forwarder = forwarders / 'wasm-tools'
forwarder.write_text(f'''#!{sys.executable}
import pathlib, shutil, subprocess, sys
args = sys.argv[1:]
result = subprocess.run([{real_wasm_tools!r}, *args])
if result.returncode == 0 and args[:2] == ['strip', '--all']:
    output = pathlib.Path(args[args.index('-o') + 1])
    shutil.copy2(output, pathlib.Path({str(capture)!r}) / output.name)
sys.exit(result.returncode)
''')
forwarder.chmod(0o755)
ENV['PATH'] = str(forwarders) + os.pathsep + ENV['PATH']
web_log = run('web-measurement', [xtask, 'wasm-size-matrix', '--surface', 'web', '--web-package-root', str(SOURCE / 'platforms/web/packages')])
typst_log = run('typst-measurement', [xtask, 'wasm-size-matrix', '--surface', 'typst'])
measurements = {}
for log in (web_log, typst_log):
    for line in log.read_text().splitlines():
        if not line.startswith('wasm-size-matrix surface='):
            continue
        fields = dict(re.findall(r'(\w+)=(\S+)', line))
        profile = fields['artifact_profile']
        metrics = {key: int(fields[key]) for key in ('raw_bytes', 'stripped_bytes', 'gzip_bytes', 'brotli_bytes')}
        artifact = Path(fields['artifact'])
        stripped = capture / (profile + '.stripped.wasm')
        assert stripped.stat().st_size == metrics['stripped_bytes']
        measurements[profile] = {'metrics': metrics, 'measured_artifact': str(artifact), 'artifact_sha256': hashlib.sha256(artifact.read_bytes()).hexdigest(), 'stripped_sha256': hashlib.sha256(stripped.read_bytes()).hexdigest()}
assert set(measurements) == set(profiles), measurements.keys()
assert measurements['typst-wasm']['metrics']['stripped_bytes'] == typst_package.stat().st_size
assert measurements['typst-wasm']['stripped_sha256'] == hashlib.sha256(typst_package.read_bytes()).hexdigest()
old = json.loads((SOURCE / 'docs/release/WASM_SIZE_BUDGETS.json').read_text())
replacement = dict(old)
replacement['updated'] = '2026-10-10'
replacement['notes'] = 'Single-source theme path retirement baseline dd79ca584; all five canonical assembled Web packages and Typst publish recipe measured with Rust 1.95.0 and Binaryen 131. Each raw, stripped, gzip and Brotli ceiling is the measured artifact plus 3%, rounded upward to 1,000 bytes. Web uses wasm-tools strip --all on final assembled npm WASM; Typst retains release wasm-opt -Oz and strip. Owner Rust compression is unchanged. Source, package checks, hashes and before/after limits are recorded in docs/performance/theme_artifact_budget_reassessment_2026-10-10.md.'
replacement['artifact_profiles'] = {profile: {'max_' + metric: (value * 103 + 99999) // 100000 * 1000 for metric, value in measurement['metrics'].items()} for profile, measurement in sorted(measurements.items())}
budget = OUTPUT / 'replacement-budgets.json'
budget.write_text(json.dumps(replacement, indent=2) + '\n')
(OUTPUT / 'measurements.json').write_text(json.dumps({'source_commit': expected, 'measurements': measurements, 'old_budgets': old, 'replacement_budgets': replacement}, indent=2) + '\n')
recheck_logs = [
    run('web-budget-recheck', [xtask, 'wasm-size-matrix', '--surface', 'web', '--web-package-root', str(SOURCE / 'platforms/web/packages'), '--budget-file', str(budget)]),
    run('typst-budget-recheck', [xtask, 'wasm-size-matrix', '--surface', 'typst', '--budget-file', str(budget)]),
]
for log in recheck_logs:
    for line in log.read_text().splitlines():
        if line.startswith('wasm-size-matrix surface='):
            fields = dict(re.findall(r'(\w+)=(\S+)', line))
            original = measurements[fields['artifact_profile']]
            assert {key: int(fields[key]) for key in original['metrics']} == original['metrics']
            assert hashlib.sha256(Path(fields['artifact']).read_bytes()).hexdigest() == original['artifact_sha256']
            assert hashlib.sha256((capture / (fields['artifact_profile'] + '.stripped.wasm')).read_bytes()).hexdigest() == original['stripped_sha256']
assert measurements['typst-wasm']['stripped_sha256'] == hashlib.sha256(typst_package.read_bytes()).hexdigest()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True).strip()
identities = {'source_commit': expected, 'source_clean': True, 'xtask_sha256': hashlib.sha256(Path(xtask).read_bytes()).hexdigest(), 'tools': {}}
for name, command in [('rust', ['rustc', '--version']), ('node', ['node', '--version']), ('npm', ['npm', '--version']), ('wasm-pack', ['wasm-pack', '--version']), ('wasm-tools', [real_wasm_tools, '--version']), ('wasm-opt', ['wasm-opt', '--version'])]:
    identities['tools'][name] = subprocess.check_output(command, env=ENV, text=True).strip()
(OUTPUT / 'identities.json').write_text(json.dumps(identities, indent=2) + '\n')
print('All six artifacts verified and 24 replacement budget metrics passed.', flush=True)
