from pathlib import Path
import json,subprocess,os,hashlib,datetime,shutil
p=Path(__file__).resolve().parent; w=Path('/Users/frankorz/Documents/projects/rust/merman/.worktrees/theme-default-ownership-20261019')
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/Users/frankorz/Documents/projects/rust/merman/target')
steps=[]
def run(name,cmd):
 print('START',name,flush=True)
 step_env=env.copy()
 if name in ('candidate1-focused-tests','candidate1-renderer-tests','candidate1-theme-acceptance'):
  step_env['CARGO_BUILD_JOBS']='4'
 with (p/(name+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=w,env=step_env,stdout=out,stderr=subprocess.STDOUT)
 steps.append(dict(name=name,command=cmd,returncode=r.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 (p/'candidate1-execution.json').write_text(json.dumps(steps,indent=2)+'\n')
 assert r.returncode==0,(name,r.returncode)
 print('PASS',name,flush=True)
run('candidate1-baseline-reference-check',['python3',str(p/'execute_base.py')])
baseline=Path(json.loads((p/'baseline-reference.json').read_text())['experiment_directory'])
for artifact,expected in json.loads((baseline/'base-frozen-probes.json').read_text()).items():
 assert hashlib.sha256(Path(artifact).read_bytes()).hexdigest()==expected,artifact
changed=subprocess.check_output(['git','diff','--name-only','--','crates'],cwd=w,text=True).splitlines()
assert set(changed)=={'crates/merman-core/src/compatibility_json.rs'},changed
run('candidate1-focused-tests',['cargo','nextest','run','--locked','--release','-p','merman-core','-p','merman','-p','merman-render','-p','merman-bindings-core','--all-features','-E','test(compatibility_json)|test(deep)|test(bounded)|test(resource)|test(cancel)|test(theme)','--test-threads','4','--cargo-quiet'])
run('candidate1-lib',['cargo','build','--locked','--release','-p','merman','--all-features','--lib','--message-format=json'])
shutil.copyfile(p/'candidate1-lib.log',p/'candidate1-lib.jsonl')
shutil.copyfile(p/'candidate1-lib.jsonl',p/'controls/candidate1-site-lib.jsonl')

artifacts=[json.loads(line) for line in (p/'candidate1-lib.jsonl').read_text().splitlines() if line.startswith('{')]
base_libraries=json.loads((baseline/'controls/base-site-probes.json').read_text())['libraries']
identity={}
for name,relative in [('merman_core','crates/merman-core/src/lib.rs'),('merman','crates/merman/src/lib.rs'),('merman_render','crates/merman-render/src/lib.rs')]:
 rows=[r for r in artifacts if r.get('reason')=='compiler-artifact' and r['target']['name']==name and r['profile']['opt_level']=='3' and not r['profile'].get('test') and any(x.endswith('.rlib') for x in r['filenames'])]
 assert len(rows)==1,name
 artifact=rows[0]
 assert Path(artifact['target']['src_path']).resolve()==(w/relative).resolve(),artifact['target']['src_path']
 library=Path(next(x for x in artifact['filenames'] if x.endswith('.rlib')))
 digest=hashlib.sha256(library.read_bytes()).hexdigest()
 assert digest!=base_libraries[name]['sha256'],('Candidate reused identical baseline library',name)
 identity[name]=dict(path=str(library),sha256=digest,base_sha256=base_libraries[name]['sha256'],source_path=artifact['target']['src_path'],cargo_fresh=artifact['fresh'])
(p/'candidate1-cross-crate-identity.json').write_text(json.dumps(identity,indent=2)+'\n')

run('candidate1-site-allocations',['python3',str(p/'controls/site_allocations.py'),'candidate1'])
run('candidate1-site-measurement-traces',['python3',str(p/'controls/site_measurement_trace.py'),'candidate1'])
run('candidate1-catalog',['python3',str(p/'capture.py'),'--library-receipt',str(p/'candidate1-lib.jsonl'),'--side','candidate1'])
run('candidate1-errors',['python3',str(p/'compare_candidate1_errors.py')])
run('candidate1-comparison',['python3',str(p/'compare_candidate1.py')])
for name in ['candidate1-controls-comparison.json','candidate1-catalog-comparison.json','candidate1-errors-comparison.json']:
 d=json.loads((p/name).read_text()); print(name,'rows',d.get('rows',d.get('cells')),'stable',d.get('stable'),'improvements',len(d.get('improvements',[])),'regressions',len(d.get('regressions',[])),flush=True)
run('candidate1-renderer-tests',['cargo','nextest','run','--locked','--release','-p','merman-core','-p','merman','-p','merman-render','-p','merman-bindings-core','--all-features','--test-threads','4','--cargo-quiet'])
run('candidate1-clippy',['cargo','clippy','--locked','--release','-p','merman-core','-p','merman','-p','merman-render','-p','merman-bindings-core','--all-features','--','-D','warnings'])
run('candidate1-dom',['cargo','run','--locked','--release','-p','xtask','--','compare-all-svgs','--check-dom','--dom-modes','structure,parity,parity-root','--dom-decimals','3','--diagnostic-browser-text-layout','--report-root'])
run('candidate1-wasm-build',['node','platforms/web/scripts/build-wasm.mjs','--package','full'])
run('candidate1-theme-acceptance',['python3','scripts/run_theme_acceptance.py','nextest','run','--locked','--release','-p','merman-theme-acceptance','--no-default-features','--features','png,all-diagrams,layout-cytoscape','--test-threads','4','--cargo-quiet'])
run('candidate1-fmt',['cargo','fmt','--all','--','--check'])
run('candidate1-diff',['git','diff','--check'])
run('candidate1-paths',['python3','scripts/check_path_lengths.py'])
print('ALL GATES PASS',flush=True)
