from pathlib import Path
import os, subprocess, json, datetime
p = Path(__file__).resolve().parent
w = Path('/Users/frankorz/Documents/projects/rust/merman/.worktrees/theme-default-ownership-20261019')
target = '/Users/frankorz/Documents/projects/rust/merman/target'
env = os.environ.copy()
env.update(CARGO_BUILD_JOBS='1', CARGO_TARGET_DIR=target)
steps = []
commands = [
    ('pipeline-discovery', ['python3', 'tools/bench/verify_pipeline_bench_list.py', '--features', 'all-diagrams,svg,layout-cytoscape,layout-elk,math', '--target-dir', target]),
    ('native-memory-smoke', ['python3', 'tools/bench/run_native_memory.py', '--smoke', '--build-timeout-seconds', '900', '--target-dir', target, '--json-out', str(p / 'native-memory-smoke.json')]),
    ('native-memory-smoke-contract', ['python3', 'tools/bench/test_native_memory_driver_contracts.py', '--verify-smoke-report', str(p / 'native-memory-smoke.json')]),
]
for name, command in commands:
    print('START', name, flush=True)
    with (p / (name + '.log')).open('w') as output:
        result = subprocess.run(command, cwd=w, env=env, stdout=output, stderr=subprocess.STDOUT)
    steps.append(dict(name=name, command=command, returncode=result.returncode, finished=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    (p / 'supplemental-execution.json').write_text(json.dumps(steps, indent=2) + '\n')
    assert result.returncode == 0, (name, result.returncode)
    print('PASS', name, flush=True)
