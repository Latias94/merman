import json, hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
load=lambda f:json.loads(f.read_text())
controls=p/'controls'
baseline=Path(load(p/'baseline-reference.json')['experiment_directory'])
a=load(baseline/'controls/base-site-allocations.json'); b=load(controls/'candidate1-site-allocations.json')
assert len(a)==len(b)==645
stable=[]; variable=[]; improvements=[]; regressions=[]
for old,new in zip(a,b):
    assert old['name']==new['name']
    assert old['svg_sha256']==new['svg_sha256'] and old['report_sha256']==new['report_sha256'], old['name']
    if not(old['stable'] and new['stable']): variable.append(old['name']); continue
    stable.append(old['name'])
    row=dict(name=old['name'],base=old['metrics'],candidate=new['metrics'])
    if any(y>x for x,y in zip(old['metrics'],new['metrics'])): regressions.append(row)
    elif old['metrics']!=new['metrics']: improvements.append(row)
assert load(baseline/'controls/base-site-measurement-traces.json')['rows']==load(controls/'candidate1-site-measurement-traces.json')['rows']
control_result=dict(rows=645,exact_svg_report_and_measurer_trace=True,stable=len(stable),variable=variable,improvements=improvements,regressions=regressions)
(p/'candidate1-controls-comparison.json').write_text(json.dumps(control_result,indent=2)+'\n')
x=load(baseline/'base/results.json'); y=load(p/'candidate1/results.json')
assert len(x)==len(y)==418
assert load(baseline/'base/catalog.json')==load(p/'candidate1/catalog.json')
changed=[]; regressed=[]; unstable=[]
for old,new in zip(x,y):
    for key in ['scene','family','preset','input_sha256','outcome','configuration','theme_status','diagnostic_codes','has_diagnostics','theme_is_satisfied','emitted_family','family_matches']:
        assert old[key]==new[key], (old['scene'],old['preset'],key)
    assert old['outcome']=='svg' and old['output_stable'] and new['output_stable'] and old['counters_valid'] and new['counters_valid']
    assert old['warmup']['result']==new['warmup']['result']
    for u,v in zip(old['samples'],new['samples']):
        assert u['result']==v['result'] and u['svg_sha256']==v['svg_sha256'] and u['report_sha256']==v['report_sha256']
    if not(old['stable'] and new['stable']): unstable.append((old['scene'],old['preset'])); continue
    row=dict(scene=old['scene'],preset=old['preset'],base=old['median_metrics'],candidate=new['median_metrics'])
    if any(new['median_metrics'][k]>v for k,v in old['median_metrics'].items()): regressed.append(row)
    elif old['median_metrics']!=new['median_metrics']: changed.append(row)
errors_a=load(baseline/'base-errors-comparison.json'); errors_b=load(p/'candidate1-errors-comparison.json')
assert errors_a==errors_b and errors_a['rows']==26 and errors_a['exact_errors']
catalog_result=dict(cells=418,exact_output_metadata=True,unstable=unstable,improvements=changed,regressions=regressed)
(p/'candidate1-catalog-comparison.json').write_text(json.dumps(catalog_result,indent=2)+'\n')
print(json.dumps(dict(controls=control_result,catalog=catalog_result),indent=2))
assert not regressions and not regressed
primary=next(row for row in changed if row['scene']=='venn_medium' and row['preset']=='none')
assert primary['base']['peak_growth_bytes']==183387,primary
assert primary['candidate']['peak_growth_bytes'] < primary['base']['peak_growth_bytes'], primary
