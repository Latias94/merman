from pathlib import Path
import datetime
import json


HERE = Path(__file__).resolve().parent
report = json.loads((HERE / "diagnostic.json").read_text())
execution = json.loads((HERE / "diagnostic-execution.json").read_text())
admission = json.loads((HERE / "inventory-admission.json").read_text())
rows = []
for row in report["rows"]:
    base = row["base_ns"]
    head = row["head_ns"]
    delta = head - base
    percent = delta / base * 100
    rows.append({
        "fixture": row["fixture"],
        "base_mean_ns": base,
        "head_mean_ns": head,
        "mean_delta_ns_head_minus_base": delta,
        "mean_delta_percent": percent,
        "within_both_goal_thresholds": abs(delta) <= 1000 and abs(percent) <= 10,
        "exceeds_both_thresholds": abs(delta) > 1000 and abs(percent) > 10,
        "exceeds_either_threshold": abs(delta) > 1000 or abs(percent) > 10,
        "diagnostic_bootstrap_bounds": row["bounds"],
        "raw_pairs_ns": [
            {"order": pair["order"], "base_ns": pair["base"]["normalized_ns"],
             "head_ns": pair["head"]["normalized_ns"], "base_postflight": pair["base"]["postflight_verified"],
             "head_postflight": pair["head"]["postflight_verified"]}
            for pair in row["raw_pairs"]
        ],
        "row_outcome": row["outcome"],
    })
rows.sort(key=lambda item: item["fixture"])
summary = {
    "generated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "status": "fresh_diagnostic_advisory_not_formal_reclassification",
    "base_production": "v0.9.0-f754a3c3077d35d2a372c2fec04f9e9b87db1c3f",
    "head_production": "68f213f1ea4676102f735bac4c158c136498eb18",
    "base_common_snapshot": "2a1ebf70af98c01ca74a64cb4567af4c1bc8880f",
    "head_common_snapshot": "6ede7452adb092d5436176b0b28795153acfe160",
    "inventory_sha256": admission["inventory_sha256"],
    "all_76_identity_admission_sha256": "inventory-admission.json",
    "timing": {
        "protocol": "generic_v2 diagnostic",
        "aa_calibrated": False,
        "balanced_orders": ["AB", "BA", "AB", "BA"],
        "pairs_per_fixture": 4,
        "sample_size": 20,
        "warm_up_seconds": 1,
        "measurement_seconds": 1,
        "relative_threshold_percent": 10,
        "absolute_threshold_ns": 1000,
        "timed_criterion_calls": execution["timed_criterion_calls"],
        "executable_and_runtime_library_identity": "verified before preparation, after preparation, immediately before first sample and after sampling",
    },
    "output_identity": {
        "fresh_fixture_count": admission["scene_count"],
        "comparable_fixture_count": admission["comparable_count"],
        "changed_svg_fixture_count": admission["changed_output_count"],
        "old_physical_svg_witnesses_rehashed": admission["old_physical_svg_files_verified"],
        "old_physical_svg_bytes_rehashed": admission["old_physical_bytes_verified"],
        "global_contract_errors": 0,
    },
    "diagnostic_result": {
        "fixtures": len(rows),
        "slower_point_estimates": sum(row["mean_delta_ns_head_minus_base"] > 0 for row in rows),
        "faster_point_estimates": sum(row["mean_delta_ns_head_minus_base"] < 0 for row in rows),
        "within_both_goal_thresholds": sum(row["within_both_goal_thresholds"] for row in rows),
        "exceeds_both_thresholds": [row["fixture"] for row in rows if row["exceeds_both_thresholds"]],
        "exceeds_either_threshold": [row["fixture"] for row in rows if row["exceeds_either_threshold"]],
        "formal_history_reclassified": False,
    },
    "rows": rows,
}
output = HERE / "diagnostic-summary.json"
assert not output.exists()
output.write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary["diagnostic_result"], indent=2))
