from pathlib import Path
import datetime
import hashlib
import json


HERE = Path(__file__).resolve().parent
PLAN = json.loads((HERE / "planning.json").read_text())
INVENTORY = json.loads((HERE / "inventory.json").read_text())
OLD_ROOT = Path(PLAN["paths"]["repository"]) / "target/bench/experiments/theme-current-v090-raw-svg-20261020"
EXPECTED = PLAN["diagnostic_fixture_order"]
FIELDS = ("schema_version", "benchmark", "output_kind", "output_bytes", "output_sha256", "svg_elements")
OLD_HASHES = json.loads((HERE / "raw-identity-minimal-plan.json").read_text())["trusted_old_witnesses"]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity_equal(left, right):
    return all(left.get(field) == right.get(field) for field in FIELDS)


registration = json.loads((HERE / "registration.json").read_text())
inv_registration = json.loads((HERE / "inventory-registration.json").read_text())
amendment = json.loads((HERE / "inventory-validator-amendment.json").read_text())
artifacts = json.loads((HERE / "prebuild-artifacts.json").read_text())
assert amendment["main_registration_sha256"] == sha(HERE / "registration.json")
assert amendment["inventory_registration_sha256"] == sha(HERE / "inventory-registration.json")
assert amendment["status"] == "VALIDATOR_ONLY_REPAIR_BEFORE_ANY_TIMED_OBSERVATIONS"
assert sha(HERE / "planning.json") == amendment["original_plan_sha256"]
assert registration["commands"]["inventory"] == inv_registration["exact_command"]
assert "Outcome: contract_failure (exit 2)" in (HERE / "inventory-execution.log").read_text()
assert INVENTORY["contract_errors"] == [] and INVENTORY["summary"]["exit_code"] == 2
assert INVENTORY["method"]["pair_count"] == 0 and INVENTORY["raw_rounds"] == []
assert len(INVENTORY["fixtures"]) == 76
assert len({row["name"] for row in INVENTORY["fixtures"]}) == 76
assert all(row["bytes"]["status"] == "identical" for row in INVENTORY["fixtures"])
assert [row["name"] for row in INVENTORY["fixtures"] if row["coverage_status"] == "comparable"] == EXPECTED
assert sum(row["coverage_status"] == "coverage_only" and row["coverage_class"] == "output_mismatch"
           for row in INVENTORY["fixtures"]) == 57
assert INVENTORY["summary"]["comparable"] == 19 and INVENTORY["summary"]["contract_failures"] == 57
for filename, expected_sha in OLD_HASHES.items():
    if filename.endswith(".json"):
        assert sha(OLD_ROOT / filename) == expected_sha, filename

inventory_start = json.loads((HERE / "inventory-start.json").read_text())
inventory_post = json.loads((HERE / "inventory-post-prepare.json").read_text())
assert inventory_start["registration_sha256"] == sha(HERE / "registration.json")
assert inventory_start["no_hook_artifacts_before"] == inventory_post["no_hook_artifacts"]
for side in ("base", "head"):
    side_artifacts = artifacts[side]
    executable = Path(side_artifacts["frozen_path"])
    executable_sha = sha(executable)
    assert executable_sha == side_artifacts["artifacts"]["pipeline"]["sha256"]
    physical = executable.read_bytes()
    assert all(marker.encode() not in physical for marker in PLAN["no_hook_markers"])
    for name in ("merman_core", "merman_render", "merman"):
        item = side_artifacts["artifacts"][name]
        assert sha(item["path"]) == item["sha256"]
    runner = INVENTORY["runners"][side]
    assert runner["executable"]["sha256"] == executable_sha
    assert Path(runner["executable"]["path"]).read_bytes() == physical
    assert runner["bench_source"]["sha256"] == PLAN["source_identity"]["common_pipeline_sha256"]
    assert runner["git"]["revision"] == side_artifacts["source"]["revision"]
    assert runner["git"]["tree"] == side_artifacts["source"]["tree"]
    assert runner["git"]["dirty"] is False
    expected_lock = PLAN["source_identity"]["base_lock_sha256" if side == "base" else "current_head_lock_sha256"]
    assert runner["lockfile"]["sha256"] == expected_lock
    assert runner["build_environment"]["CARGO_BUILD_JOBS"] == "1"

old_registered = {row["name"]: row for row in json.loads((OLD_ROOT / "registered-corpus.json").read_text())}
old_pairs = {row["name"]: row for row in json.loads((OLD_ROOT / "pairs.json").read_text())}
assert len(old_registered) == 76 and len(old_pairs) == 76
new_by_name = {row["name"]: row for row in INVENTORY["fixtures"]}
physical_rows = []
exact_names = []
for name in sorted(new_by_name):
    fresh = new_by_name[name]
    old = old_registered[name]
    pair = old_pairs[name]
    assert fresh["bytes"]["base"]["sha256"] == fresh["bytes"]["head"]["sha256"] == old["input_sha256"]
    current = fresh["output_identity"]
    for side in ("base", "head"):
        previous = old[side + "_identity"]
        actual = current[side]
        assert identity_equal(actual, previous), (name, side, actual, previous)
        raw_path = OLD_ROOT / side / (name + ".svg")
        data = raw_path.read_bytes()
        raw_sha = hashlib.sha256(data).hexdigest()
        assert len(data) == previous["output_bytes"] and raw_sha == previous["output_sha256"], (name, side)
        assert raw_sha == pair[side + "_sha256"]
        physical_rows.append(dict(name=name, side=side, bytes=len(data), sha256=raw_sha,
                                  identity=actual, raw_path=str(raw_path)))
    matches = pair["exact"] is True
    assert matches == identity_equal(current["base"], current["head"])
    if matches:
        exact_names.append(name)

assert set(exact_names) == set(EXPECTED)
receipt = dict(
    completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    status="FRESH_76_INVENTORY_ADMITTED_FOR_FIXED_19_DIAGNOSTIC",
    validator_amendment_sha256=sha(HERE / "inventory-validator-amendment.json"),
    validator_sha256=sha(__file__), inventory_sha256=sha(HERE / "inventory.json"),
    inventory_log_sha256=sha(HERE / "inventory-execution.log"),
    inventory_exit_observed_from_cli="Outcome: contract_failure (exit 2)",
    global_contract_errors=0, scene_count=76, comparable_count=19, changed_output_count=57,
    timed_observations=0, raw_pair_count=0, fixed_exact_names=EXPECTED,
    old_physical_svg_files_verified=len(physical_rows), old_physical_bytes_verified=sum(row["bytes"] for row in physical_rows),
    old_physical_svg_sha256_sum=hashlib.sha256("".join(row["sha256"] for row in physical_rows).encode()).hexdigest(),
    raw_identity_amendment_sha256=sha(HERE / "raw-identity-minimal-plan.json"),
    physical_rows=physical_rows,
    no_hook_binary_and_runtime_library_identities_unchanged_before_and_after_discovery=True,
    source_pipeline_sha256=PLAN["source_identity"]["common_pipeline_sha256"],
    note="CLI output is exit 2 because 57 cross-version SVG identities differ. The wrapper wrote the complete report and log, then failed only in its receipt validator due to a missing derived registration field. This independent registered-data audit reads the common pipeline digest from the registered source plan; no benchmark samples were collected.",
)
out = HERE / "inventory-admission.json"
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2) + "\n")
print("INVENTORY ADMITTED", json.dumps({key: receipt[key] for key in (
    "status", "inventory_sha256", "global_contract_errors", "scene_count", "comparable_count",
    "changed_output_count", "timed_observations", "old_physical_svg_files_verified",
    "old_physical_bytes_verified", "old_physical_svg_sha256_sum")}, separators=(",", ":")))
