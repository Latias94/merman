from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys


HERE = Path(__file__).resolve().parent
PLAN = json.loads((HERE / "planning.json").read_text())
ROOT = Path(PLAN["paths"]["repository"])
PRODUCTION = "68f213f1ea4676102f735bac4c158c136498eb18"
COMMON = "6ede7452adb092d5436176b0b28795153acfe160"
ENV = dict(os.environ, **PLAN["recipe"]["environment"])


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n")


def git(worktree, *arguments):
    return subprocess.check_output(["git", "-C", str(worktree), *arguments], text=True).strip()


def source_identity(side):
    worktree = Path(PLAN["paths"]["existing_base_common_checkout" if side == "base" else "new_head_common_checkout"])
    expected = PLAN["source_identity"]["existing_base_common_sha"] if side == "base" else COMMON
    production = PLAN["source_identity"]["base_production_sha"] if side == "base" else PRODUCTION
    assert git(worktree, "rev-parse", "HEAD") == expected
    assert git(worktree, "status", "--porcelain") == ""
    assert git(worktree, "diff", "--name-only", production, "HEAD") == "crates/merman/benches/pipeline.rs"
    assert sha(worktree / "crates/merman/benches/pipeline.rs") == PLAN["source_identity"]["common_pipeline_sha256"]
    assert sha(worktree / "Cargo.lock") == PLAN["source_identity"]["base_lock_sha256" if side == "base" else "current_head_lock_sha256"]
    return dict(worktree=str(worktree), revision=expected, tree=git(worktree, "rev-parse", "HEAD^{tree}"), production=production)


def execute(name, command, cwd, expected=0):
    log = HERE / (name + ".log")
    assert not log.exists(), log
    start = now()
    print("START", name, flush=True)
    with log.open("w") as output:
        result = subprocess.run(command, cwd=cwd, env=ENV, stdout=output, stderr=subprocess.STDOUT)
    record = dict(stage=name, command=command, cwd=str(cwd), started_at_utc=start,
                  finished_at_utc=now(), returncode=result.returncode, log_sha256=sha(log))
    records.append(record)
    save("build-execution.json", records)
    assert result.returncode == expected, (name, result.returncode)
    print("PASS", name, flush=True)
    return log


assert not (HERE / "registration.json").exists()
identities = {side: source_identity(side) for side in ("base", "head")}
consumer = Path(PLAN["paths"]["consumer_checkout"])
assert git(consumer, "rev-parse", "HEAD") == PRODUCTION
assert git(consumer, "status", "--porcelain") == ""
for relative, expected in PLAN["source_identity"]["consumer_sha256"].items():
    assert sha(consumer / relative) == expected
common = [item.replace("FINAL_HEAD_SHA", PRODUCTION) for item in PLAN["common_compare_arguments"]]
prefix = ["python3", str(consumer / "tools/bench/compare_self.py"), *common]
registration = dict(
    registered_at_utc=now(), status="REGISTERED_BEFORE_FRESH_BUILDS_AND_OBSERVATIONS",
    original_plan_sha256=sha(HERE / "planning.json"),
    raw_identity_amendment_sha256=sha(HERE / "raw-identity-minimal-plan.json"),
    driver_sha256=sha(__file__), source_identity=identities,
    production_head=PRODUCTION, production_tree=git(consumer, "rev-parse", "HEAD^{tree}"),
    common_pipeline_sha256=PLAN["source_identity"]["common_pipeline_sha256"],
    environment={key: ENV.get(key) for key in (
        "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL", "CARGO_PROFILE_BENCH_DEBUG",
        "CARGO_PROFILE_BENCH_CODEGEN_UNITS", "CARGO_PROFILE_BENCH_LTO",
        "CARGO_PROFILE_BENCH_OPT_LEVEL", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS")},
    commands={"inventory": prefix + PLAN["fresh_inventory_arguments"],
              "diagnostic": prefix + PLAN["diagnostic_arguments"]},
    command_cwd=str(consumer), build_commands=PLAN["prebuild_commands_not_run"],
    fixture_order=PLAN["diagnostic_fixture_order"],
    chosen_raw_identity_gate="Fresh full76 same-side complete SVG receipts must match all previously audited physical witnesses. Verify stored physical bytes once. Any unmatched row stops this shortcut and requires targeted capture/replay. No capture-hook builds for matching rows.",
    timing="Fresh diagnostic only: four fixed AB/BA pairs,20samples,1s warmup,1s measurement,explicit10percent/1000ns. Historical formal14/2/3 remains unchanged.",
    concurrency="Single native owner; no parallel Cargo, tests, profiling or allocation probes.",
)
save("registration.json", registration)
records = []
artifacts = {}
for side in ("base", "head"):
    identity = identities[side]
    worktree = Path(identity["worktree"])
    execute(side + "-bounded-clean", PLAN["prebuild_commands_not_run"][side + "_bounded_clean"], worktree)
    log = execute(side + "-prebuild", PLAN["prebuild_commands_not_run"][side + "_prebuild"], worktree)
    messages = []
    for line in log.read_text().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get("reason") == "compiler-artifact":
            messages.append(row)
    side_artifacts = {}
    for target in ("merman_core", "merman_render", "merman", "pipeline"):
        selected = [row for row in messages if row["target"]["name"] == target]
        if target != "pipeline":
            selected = [row for row in selected if row["target"]["kind"] == ["lib"]]
        assert len(selected) == 1, (side, target, len(selected))
        row = selected[0]
        assert row["fresh"] is False, (side, target, "stale artifact")
        assert row["profile"]["opt_level"] == "3", (side, target, row["profile"])
        assert Path(row["manifest_path"]).is_relative_to(worktree / "crates"), row["manifest_path"]
        assert Path(row["target"]["src_path"]).is_relative_to(worktree / "crates")
        files = [path for path in row["filenames"] if path.endswith(".rlib")]
        if target == "pipeline":
            assert row["target"]["kind"] == ["bench"]
            assert Path(row["target"]["src_path"]) == worktree / "crates/merman/benches/pipeline.rs"
            files = [row["executable"]]
        assert len(files) == 1, (side, target, files)
        side_artifacts[target] = dict(fresh=False, profile=row["profile"], features=row["features"],
            manifest_path=row["manifest_path"], src_path=row["target"]["src_path"],
            path=files[0], sha256=sha(files[0]))
    executable = Path(side_artifacts["pipeline"]["path"])
    physical = executable.read_bytes()
    assert all(marker.encode() not in physical for marker in PLAN["no_hook_markers"])
    frozen = HERE / ("no-hook-" + side)
    assert not frozen.exists()
    shutil.copyfile(executable, frozen)
    frozen.chmod(0o555)
    assert sha(frozen) == side_artifacts["pipeline"]["sha256"]
    artifacts[side] = dict(source=identity, artifacts=side_artifacts, frozen_path=str(frozen),
                           hook_markers_absent=True, checked_at_utc=now())
    save("prebuild-artifacts.json", artifacts)
assert artifacts["base"]["artifacts"]["merman_render"]["sha256"] != artifacts["head"]["artifacts"]["merman_render"]["sha256"]
assert artifacts["base"]["artifacts"]["pipeline"]["sha256"] != artifacts["head"]["artifacts"]["pipeline"]["sha256"]
assert all(source_identity(side) == identities[side] for side in identities)
print("PREBUILD TERMINAL: fresh source-bound runtime libraries and no-hook executables; inventory remains pending", flush=True)
