from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time


HERE = Path(__file__).resolve().parent


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_identities():
    artifacts = json.loads((HERE / "prebuild-artifacts.json").read_text())
    result = {}
    for side in ("base", "head"):
        item = artifacts[side]
        exe = Path(item["frozen_path"])
        digest = sha(exe)
        assert digest == item["artifacts"]["pipeline"]["sha256"]
        content = exe.read_bytes()
        plan = json.loads((HERE / "planning.json").read_text())
        assert all(marker.encode() not in content for marker in plan["no_hook_markers"])
        libs = {}
        for name in ("merman_core", "merman_render", "merman"):
            artifact = item["artifacts"][name]
            current = sha(artifact["path"])
            assert current == artifact["sha256"], (side, name, current, artifact["sha256"])
            libs[name] = current
        result[side] = {"executable": str(exe), "sha256": digest, "runtime_libraries": libs}
    return result


registration_path = HERE / "diagnostic-registration.json"
assert registration_path.exists()
registration = json.loads(registration_path.read_text())
assert registration["status"] == "FRESH_DIAGNOSTIC_REGISTERED_BEFORE_TIMED_OBSERVATIONS"
assert registration["driver_sha256"] == sha(__file__)
assert registration["inventory_admission_sha256"] == sha(HERE / "inventory-admission.json")
assert registration["command"] == json.loads((HERE / "registration.json").read_text())["commands"]["diagnostic"]
assert registration["no_hook_identity_before_sampling"] == verify_identities()
assert not (HERE / "diagnostic-start.json").exists()
start = dict(started_at_utc=now(), registration_sha256=sha(registration_path),
             command=registration["command"], cwd=registration["cwd"],
             inventory_sha256=sha(HERE / "inventory.json"),
             inventory_admission_sha256=sha(HERE / "inventory-admission.json"),
             no_hook_identity_before_sampling=verify_identities(), no_aa_samples=True)
(HERE / "diagnostic-start.json").write_text(json.dumps(start, indent=2) + "\n")
log = HERE / "diagnostic-execution.log"
assert not log.exists()
identity_error = None
post_prepare = None
first_measurement = None
env = dict(os.environ, **json.loads((HERE / "planning.json").read_text())["recipe"]["environment"])
with log.open("w") as output:
    process = subprocess.Popen(start["command"], cwd=start["cwd"], env=env,
                               stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    with log.open() as observed:
        while process.poll() is None:
            text = observed.read()
            if post_prepare is None and "[discover] head:" in text:
                try:
                    post_prepare = dict(checked_at_utc=now(), no_hook_identity=verify_identities())
                    (HERE / "diagnostic-post-prepare.json").write_text(json.dumps(post_prepare, indent=2) + "\n")
                except Exception as error:
                    identity_error = repr(error)
                    os.killpg(process.pid, signal.SIGTERM)
                    break
            if first_measurement is None and "[measure 1]" in text:
                try:
                    first_measurement = dict(checked_at_utc=now(), no_hook_identity=verify_identities())
                    (HERE / "diagnostic-pre-sample.json").write_text(json.dumps(first_measurement, indent=2) + "\n")
                except Exception as error:
                    identity_error = repr(error)
                    os.killpg(process.pid, signal.SIGTERM)
                    break
            time.sleep(0.1 if first_measurement is None else 0.5)
    returncode = process.wait()
try:
    final_identity = verify_identities()
except Exception as error:
    final_identity = None
    identity_error = identity_error or repr(error)

report_path = HERE / "diagnostic.json"
report = json.loads(report_path.read_text()) if report_path.exists() else None
valid = returncode == 0 and identity_error is None and post_prepare is not None and first_measurement is not None and report is not None
if valid:
    method = report["method"]
    valid = method["evidence_mode"] == "diagnostic" and method["confirmation_protocol"] == "generic_v2"
    valid = valid and method["sample_size"] == 20 and method["warm_up_seconds"] == 1 and method["measurement_seconds"] == 1
    valid = valid and method["pair_count"] == 4 and method["relative_threshold_percent"] == 10.0
    valid = valid and method["absolute_threshold_ns"] == 1000.0 and method["start_side"] == "base"
    valid = valid and report["contract_errors"] == [] and report["summary"]["outcome"] == "diagnostic_advisory"
    valid = valid and report["summary"]["comparable"] == 19 and report["summary"]["contract_failures"] == 0
    rows = {row["fixture"]: row for row in report["rows"]}
    valid = valid and set(rows) == set(registration["fixture_order"]) and len(report["rows"]) == 19
    inventory = {row["name"]: row for row in json.loads((HERE / "inventory.json").read_text())["fixtures"]}
    for name, row in rows.items():
        pairs = row["raw_pairs"]
        valid = valid and row["pair_count"] == 4 and len(pairs) == 4
        valid = valid and [pair["order"] for pair in pairs] == ["AB", "BA", "AB", "BA"]
        valid = valid and [pair["pair_index"] for pair in pairs] == [0, 1, 2, 3]
        valid = valid and all(pair[side]["postflight_verified"] for pair in pairs for side in ("base", "head"))
        valid = valid and row["coverage_status"] == "comparable"
        valid = valid and row["output_identity"] == inventory[name]["output_identity"]
        valid = valid and all("--sample-size" in pair[side]["command"] and
                              pair[side]["command"][pair[side]["command"].index("--sample-size") + 1] == "20"
                              for pair in pairs for side in ("base", "head"))
    valid = valid and len(report["raw_rounds"]) == 4
execution = dict(finished_at_utc=now(), returncode=returncode, log_sha256=sha(log),
                 diagnostic_sha256=sha(report_path) if report_path.exists() else None,
                 post_prepare_identity=post_prepare, pre_first_sample_identity=first_measurement,
                 final_identity=final_identity, identity_error=identity_error,
                 inventory_admission_sha256=sha(HERE / "inventory-admission.json"),
                 diagnostic_admitted=bool(valid), timed_criterion_calls=152 if report and report.get("raw_rounds") else 0)
(HERE / "diagnostic-execution.json").write_text(json.dumps(execution, indent=2) + "\n")
print("DIAGNOSTIC TERMINAL", json.dumps({key: execution[key] for key in (
    "returncode", "diagnostic_sha256", "diagnostic_admitted", "timed_criterion_calls", "identity_error")},
    separators=(",", ":")), flush=True)
sys.exit(0 if valid else 2)
