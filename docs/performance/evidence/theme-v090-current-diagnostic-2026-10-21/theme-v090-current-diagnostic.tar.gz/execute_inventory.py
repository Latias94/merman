from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time


HERE = Path(__file__).resolve().parent


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


registration_path = HERE / "registration.json"
artifacts_path = HERE / "prebuild-artifacts.json"
assert registration_path.exists() and artifacts_path.exists()
registration = json.loads(registration_path.read_text())
artifacts = json.loads(artifacts_path.read_text())
plan = json.loads((HERE / "planning.json").read_text())
env = dict(os.environ, **plan["recipe"]["environment"])
assert registration["status"] == "REGISTERED_BEFORE_FRESH_BUILDS_AND_OBSERVATIONS"


def verify():
    receipt = {}
    for side in ("base", "head"):
        side_artifacts = artifacts[side]
        executable = Path(side_artifacts["frozen_path"])
        expected = side_artifacts["artifacts"]["pipeline"]["sha256"]
        assert sha(executable) == expected
        content = executable.read_bytes()
        assert all(marker.encode() not in content for marker in ("MERMAN_BENCH_CAPTURE_SVG_DIR", "capture output changed:", "capture SVG must be writable"))
        for name, item in side_artifacts["artifacts"].items():
            assert Path(item["path"]).is_file()
            if name != "pipeline":
                assert sha(item["path"]) == item["sha256"]
        receipt[side] = dict(path=str(executable), sha256=sha(executable), runtime_library_sha256={
            name: side_artifacts["artifacts"][name]["sha256"] for name in ("merman_core", "merman_render", "merman")})
    return receipt


assert not (HERE / "inventory-start.json").exists()
start = dict(started_at_utc=now(), registration_sha256=sha(registration_path),
             command=registration["commands"]["inventory"], cwd=registration["command_cwd"],
             no_hook_artifacts_before=verify())
(HERE / "inventory-start.json").write_text(json.dumps(start, indent=2) + "\n")
log = HERE / "inventory-execution.log"
assert not log.exists()
identity_error = None
post_prepare = None
with log.open("w") as output:
    process = subprocess.Popen(start["command"], cwd=start["cwd"], env=env,
                               stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    with log.open() as observed:
        while process.poll() is None:
            if post_prepare is None:
                contents = observed.read()
                if "[discover] head:" in contents:
                    try:
                        post_prepare = dict(checked_at_utc=now(), no_hook_artifacts=verify())
                        (HERE / "inventory-post-prepare.json").write_text(json.dumps(post_prepare, indent=2) + "\n")
                    except Exception as error:
                        identity_error = repr(error)
                        os.killpg(process.pid, signal.SIGTERM)
                        break
            time.sleep(0.1 if post_prepare is None else 0.5)
    result = process.wait()
try:
    final = verify()
except Exception as error:
    final = None
    identity_error = identity_error or repr(error)
report_path = HERE / "inventory.json"
report = json.loads(report_path.read_text()) if report_path.exists() else None
valid = result == 2 and identity_error is None and post_prepare is not None and report is not None
if valid:
    valid = report["contract_errors"] == [] and len(report["fixtures"]) == 76 and len({row["name"] for row in report["fixtures"]}) == 76
    valid = valid and all(row["bytes"]["status"] == "identical" for row in report["fixtures"])
    valid = valid and sum(row["coverage_status"] == "comparable" for row in report["fixtures"]) == 19
    valid = valid and sum(row["coverage_status"] == "coverage_only" and row["coverage_class"] == "output_mismatch"
                          for row in report["fixtures"]) == 57
    valid = valid and report["summary"]["comparable"] == 19 and report["summary"]["contract_failures"] == 57
    valid = valid and report["method"]["pair_count"] == 0 and report["raw_rounds"] == []
    for side in ("base", "head"):
        runner = report["runners"][side]
        expected = artifacts[side]["artifacts"]["pipeline"]
        valid = valid and runner["executable"]["sha256"] == expected["sha256"]
        valid = valid and Path(runner["executable"]["path"]).read_bytes() == Path(artifacts[side]["frozen_path"]).read_bytes()
        valid = valid and runner["bench_source"]["sha256"] == registration["common_pipeline_sha256"]
        valid = valid and runner["git"]["revision"] == registration["source_identity"][side]["revision"]
        valid = valid and runner["build_environment"]["CARGO_BUILD_JOBS"] == "1"
receipt = dict(finished_at_utc=now(), returncode=result, log_sha256=sha(log),
               inventory_sha256=sha(report_path) if report_path.exists() else None,
               post_prepare_identity=post_prepare, final_identity=final,
               global_contract_errors=report.get("contract_errors") if report else None,
               comparable=report.get("summary", {}).get("comparable") if report else None,
               expected_output_mismatches=report.get("summary", {}).get("contract_failures") if report else None,
               inventory_admitted=bool(valid), identity_error=identity_error)
(HERE / "inventory-execution.json").write_text(json.dumps(receipt, indent=2) + "\n")
print("INVENTORY TERMINAL", json.dumps(receipt, separators=(",", ":")), flush=True)
sys.exit(0 if valid else 2)
