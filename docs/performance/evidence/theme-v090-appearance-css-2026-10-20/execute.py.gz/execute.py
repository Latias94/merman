from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
sha = lambda f: hashlib.sha256(Path(f).read_bytes()).hexdigest()
read = lambda f: json.loads(Path(f).read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
d = read(p / 'experiment.yaml')
gate = read(p / 'pre-sampling-review.json')
assert gate['blockers'] == [] and gate['admitted_for_fresh_formal_sampling'] is True
for path, expected in gate['identities'].items():
    assert sha(path) == expected, path
inventory = read(gate['fresh_inventory_path'])
assert sha(gate['fresh_inventory_path']) == gate['fresh_inventory_sha256']
assert inventory['contract_errors'] == []
assert sha(d['inventory_path']) == d['inventory_sha256']
raw = Path(d['raw_run'])
assert sha(raw / 'experiment.yaml') == d['raw_registration_sha256']
pairs = read(raw / 'pairs.json')
assert len(pairs) == 76 and {r['name'] for r in pairs if r['exact']} == set(d['fixture_order'])
assert len(d['fixture_order']) == 19
raw_execution = read(raw / 'execution.json')
assert len(raw_execution) == 5 and all(r['returncode'] == 0 for r in raw_execution)
raw_review = read(raw / 'final-gates-review.json')
assert raw_review['blockers'] == [] and raw_review['admitted_for_registered_formal_confirmation'] is True
for side, snapshot in d['benchmark_snapshots'].items():
    cwd = snapshot['worktree']
    assert subprocess.check_output(['git', '-C', cwd, 'rev-parse', 'HEAD'], text=True).strip() == snapshot['benchmark_revision']
    assert subprocess.check_output(['git', '-C', cwd, 'status', '--porcelain'], text=True) == ''
    assert sha(Path(cwd) / 'crates/merman/benches/pipeline.rs') == snapshot['pipeline_sha256']

markers = [m.encode() for m in d['identity_repair']['absent_hook_markers']]
def verify_executables():
    results = {}
    for side in ['base', 'head']:
        exe = inventory['runners'][side]['executable']
        physical = Path(exe['path']).read_bytes()
        digest = hashlib.sha256(physical).hexdigest()
        assert digest == exe['sha256'] == gate['frozen_executable_sha256'][side], side
        assert all(marker not in physical for marker in markers), side
        results[side] = {'path': exe['path'], 'sha256': digest, 'hook_markers_absent': True}
    return results

assert not (p / 'confirmation.json').exists() and not (p / 'start-receipt.json').exists()
start = {
    'started_at_utc': now(), 'registration_sha256': sha(p / 'experiment.yaml'),
    'driver_sha256': sha(__file__), 'pre_sampling_review_sha256': sha(p / 'pre-sampling-review.json'),
    'fresh_inventory_sha256': gate['fresh_inventory_sha256'],
    'raw_pairs_sha256': sha(raw / 'pairs.json'), 'raw_review_sha256': sha(raw / 'final-gates-review.json'),
    'actual_executables': verify_executables(), 'new_samples_only': True,
}
(p / 'start-receipt.json').write_text(json.dumps(start, indent=2) + '\n')
print('START fresh official joint A/A -> fixed AB/BA; verified no-hook executables; no other native work', flush=True)
identity_error = None
prepare_check = None
with (p / 'confirmation.log').open('w') as out:
    process = subprocess.Popen(d['command']['argv'], cwd=d['command']['cwd'], env=dict(os.environ, **d['command']['environment']), stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
    with (p / 'confirmation.log').open() as observed:
        while process.poll() is None:
            if prepare_check is None:
                new_text = observed.read()
                if '[discover] head:' in new_text or '[measure ' in new_text:
                    try:
                        prepare_check = {'checked_at_utc': now(), 'actual_executables': verify_executables()}
                        (p / 'post-prepare-identity.json').write_text(json.dumps(prepare_check, indent=2) + '\n')
                        print('POST-PREPARE identities unchanged: base8712a3bb / head6da05572; hook markers absent', flush=True)
                    except Exception as exc:
                        identity_error = repr(exc)
                        os.killpg(process.pid, signal.SIGTERM)
                        break
            time.sleep(0.1 if prepare_check is None else 1)
    result = process.wait()
try:
    final_identities = verify_executables()
except Exception as exc:
    final_identities = None
    identity_error = identity_error or repr(exc)
receipt = {
    'command': d['command'], 'returncode': result, 'finished': now(),
    'report_sha256': sha(p / 'confirmation.json') if (p / 'confirmation.json').exists() else None,
    'post_prepare_check': prepare_check, 'final_actual_executables': final_identities,
    'identity_error': identity_error, 'identity_admitted': identity_error is None and prepare_check is not None,
}
(p / 'execution.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('FORMAL TERMINAL', result, d['expected_exit_codes'].get(str(result), 'unexpected_failure'), 'identity_admitted', receipt['identity_admitted'], flush=True)
sys.exit(result if receipt['identity_admitted'] else 2)
