"""Verify archived fresh-process SVG reports and inventory the unmodified outputs."""

from collections import Counter
import json
from pathlib import Path
from statistics import median
import sys

from collect import HERE, PLAN, PRODUCTS, check_plan, cli, encoded, file_hash
from workload_reference import compare_reference


def verify_fresh(directory):
    check_plan()
    frozen = json.loads(PLAN.read_bytes())
    reports, output = [], {}
    for engine in PRODUCTS:
        path = directory / f'{engine}-svg.json'
        raw = json.loads(path.read_bytes())
        reports.append(raw)
        if (raw['engine'] != engine or raw['plan_sha256'] != file_hash(PLAN) or raw['samples'] != 3
                or raw['process_lifecycle'] != 'fresh-process-per-diagram' or raw['format'] != 'svg'
                or raw['artifact_identity']['status'] != 'recorded'):
            raise ValueError(f'unexpected collector or input identity in {path}')
        [run] = [folder for folder in (directory / 'files').glob(f'{engine}-svg-*') if folder.is_dir()]
        scenarios = []
        for case, expected in zip(raw['scenarios'], frozen['scenarios'], strict=True):
            if case['id'] != expected['id'] or len(case['batches']) != 3:
                raise ValueError('scenario identity or sample count changed')
            results = []
            for req, old in zip(case['requests'], expected['requests'], strict=True):
                if (any(req[key] != old[key] for key in ('fixture','diagram_id','source_sha256','expected_labels','expected_outcome'))
                        or (run / req['input']).read_bytes() != old['source'].encode()):
                    raise ValueError('raw source, request identity or reviewed facts differ from frozen plan')
            for batch in case['batches']:
                for req, row in zip(case['requests'], batch['results'], strict=True):
                    svg = run / row['output']
                    if 'sha256' in row and (file_hash(svg) != row['sha256'] or svg.stat().st_size != row['bytes']):
                        raise ValueError(f'changed SVG: {svg}')
                    if row['status'] == 'ok':
                        recorded = cli.verify_output(svg, 'svg', req['expected_labels'], req['expected_outcome'])
                        if any(row[key] != value for key, value in recorded.items()):
                            raise ValueError(f'SVG postflight mismatch: {svg}')
                    results.append(row['status'])
            errors = []
            for i, req in enumerate(case['requests']):
                for n, batch in enumerate(case['batches'], 1):
                    row = batch['results'][i]
                    if row['status'] != 'ok':
                        errors.append(dict(fixture=req['fixture'], round=n, status=row['status'],
                                           diagnostic=row.get('error',row.get('log_tail',''))))
            scenarios.append(dict(id=case['id'], distinct=len(case['requests']), complete_output_checks=results.count('ok'),
                                  observed=dict(Counter(results)), errors=errors,
                                  wall_samples_ms=[b['wall_ms'] for b in case['batches']]))
        output[engine] = dict(report=path.relative_to(HERE).as_posix(), sha256=file_hash(path),
                              archived_run_dir=run.relative_to(HERE).as_posix(),
                              version=raw['version'], collector=raw['collector_sha256'], status=raw['status'],
                              completed=raw['completed'], failed=raw['failed'], scenarios=scenarios)
    comparison = compare_reference(*reports)
    (directory / 'comparison.json').write_bytes(encoded(comparison))
    summary = dict(plan_sha256=file_hash(PLAN), scope='SVG validity, nonempty drawing, source-derived visible labels and within-engine byte stability',
                   products=output, ratio_withheld_reason=comparison['ratio_withheld_reason'],
                   scenarios=[dict(id=s['id'], planned=s['planned_requests'], common_completed=s['common_completed'],
                                   common_stable=s['common_stable'], complete_batch_ms=s.get('complete_batch_ms'),
                                   noncommon=[dict(fixture=r['fixture'],left=r['left']['state'],right=r['right']['state']) for r in s['requests']
                                              if r['left']['state'] != 'stable' or r['right']['state'] != 'stable'])
                              for s in comparison['scenarios']])
    (directory / 'audit.json').write_bytes(encoded(summary))
    print(json.dumps([dict(id=s['id'], common_completed=s['common_completed'], common_stable=s['common_stable']) for s in summary['scenarios']]))


def summarize_native(directory):
    raw = json.loads((directory / 'native-batch.json').read_bytes())
    if raw['markdown_sha256'] != file_hash(HERE / 'document.md') or raw['plan_sha256'] != file_hash(PLAN):
        raise ValueError('native batch does not use the frozen collection')
    from collect import batch_outputs
    reqs = check_plan()
    expected_order = ['merman','mmdc','mmdc','merman','merman','mmdc']
    if [r['engine'] for r in raw['rows']] != expected_order:
        raise ValueError('unexpected native run order')
    summary = {}
    all_stable = True
    for engine in PRODUCTS:
        entries = [r for r in raw['rows'] if r['engine'] == engine]
        for entry in entries:
            audited = batch_outputs(directory / entry['output'], HERE / 'document.md', reqs)
            if audited != entry['validation']:
                raise ValueError(f'native outputs have changed: {entry["output"]}')
        passed = [e['result']['status'] == 'ok' and e['validation']['passed'] for e in entries]
        digests = [{r['fixture']: r.get('sha256') for r in e['validation']['rows'] if r['status'] == 'ok'} for e in entries]
        stable = sum(all(d.get(q['fixture']) for d in digests) and len({d[q['fixture']] for d in digests}) == 1 for q in reqs)
        all_stable = all_stable and all(passed) and stable == len(reqs)
        ms = [e['result']['elapsed_ms'] for e in entries]
        summary[engine] = dict(validated_documents=sum(passed), validated_svgs=[sum(r['status'] == 'ok' for r in e['validation']['rows']) for e in entries],
                               distinct_stable_svgs=stable, wall_samples_ms=ms, median_validated_document_ms=median(ms) if all(passed) else None)
    receipt = dict(scope='one native CLI invocation, sequential charts, Markdown plus linked SVG assets',
                   svg_sources=len(reqs), products=summary, complete_stable_comparison=all_stable,
                   ratio_right_over_left=(summary['mmdc']['median_validated_document_ms']/summary['merman']['median_validated_document_ms'] if all_stable else None))
    (directory / 'audit.json').write_bytes(encoded(receipt))
    print(json.dumps(receipt))


def summarize_png(directory):
    from itertools import product
    raw = json.loads((directory / 'png-probe.json').read_bytes())
    plan = json.loads((HERE / 'png-plan.json').read_bytes())
    if raw['plan_sha256'] != file_hash(HERE / 'png-plan.json') or raw['config_sha256'] != file_hash(HERE / 'png-config.json'):
        raise ValueError('PNG control inputs have changed')
    by_id = {s['id']:s['requests'][0] for s in plan['scenarios']}
    rows = {}
    for expected, r in zip(product(by_id, PRODUCTS), raw['rows'], strict=True):
        name, engine = expected
        if expected != (r['scenario'], r['engine']) or file_hash(directory / f'{name}.mmd') != by_id[name]['source_sha256']:
            raise ValueError('unexpected controlled PNG source or product')
        for fmt in ('png','svg'):
            stored = r[fmt]
            actual = cli.verify_output(directory / stored['output'], fmt, by_id[name]['expected_labels'])
            if stored['result']['returncode'] or any(stored[key] != value for key, value in actual.items()):
                raise ValueError('PNG or SVG witness changed')
        rows.setdefault(name, {})[engine] = [r['png']['width'], r['png']['height']]
    dims = {name:dict(dimensions=pair, equal_dimensions=pair['merman']==pair['mmdc']) for name,pair in rows.items()}
    summary = dict(kind='untimed-capability-probe', requested_font=raw['font_family'], requested_scale=raw['requested_scale'],
                   requested_long_edge_css_px=raw['requested_css_long_edge'],
                   native_fonts=raw['font_files'], browser_font_evidence='configured family, physical glyph face unobserved',
                   observable='decoded nonuniform PNG on white and matching source labels in a companion SVG',
                   rows=dims, controlled_timing_samples=0)
    (directory / 'audit.json').write_bytes(encoded(summary))
    print(json.dumps(dims))


if __name__ == '__main__':
    audits = {'fresh':verify_fresh,'native':summarize_native,'png':summarize_png}
    if len(sys.argv) != 3 or sys.argv[1] not in audits:
        sys.exit('Use fresh <raw directory> | native <raw directory> | png <probe directory>')
    folder = Path(sys.argv[2]).resolve()
    if not folder.is_relative_to(HERE):
        sys.exit('raw directory must be inside the experiment')
    audits[sys.argv[1]](folder)
