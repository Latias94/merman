"""Run the fresh-process SVG collector or the separate native Markdown batch."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

from freeze import HERE, OLD, SCENARIO, WORKTREE, encoded

import workload_cli as cli


RELEASE = OLD.parent / 'post011-flowchart-geometry/published-cli'


def location(variable, local, command=None):
    value = os.environ.get(variable)
    if value:
        return Path(shutil.which(value) or value).expanduser().resolve()
    if local.is_file() or not command:
        return local
    return Path(shutil.which(command) or local)


MER = location('MERMAN_BENCH_CLI', RELEASE / 'unpacked/merman-cli.exe', 'merman-cli')
shim = 'mmdc.cmd' if os.name == 'nt' else 'mmdc'
MMDC = location('MERMAN_BENCH_MMDC', WORKTREE / 'tools/mermaid-cli/node_modules/.bin' / shim, 'mmdc')


def installed_chrome():
    configured = os.environ.get('PUPPETEER_EXECUTABLE_PATH')
    if configured:
        return Path(configured).expanduser()
    for name in ('google-chrome', 'google-chrome-stable', 'chromium', 'chrome'):
        if path := shutil.which(name):
            return Path(path)
    for key in ('ProgramFiles', 'ProgramFiles(x86)', 'LOCALAPPDATA'):
        if base := os.environ.get(key):
            path = Path(base) / 'Google/Chrome/Application/chrome.exe'
            if path.is_file():
                return path
    return Path('chrome')


CHROME = location('MERMAN_BENCH_CHROME', installed_chrome())
system_root = os.environ.get('WINDIR') or os.environ.get('SystemRoot')
font_directory = Path(system_root) / 'Fonts' if system_root else HERE / 'cache/fonts'
FONT = location('MERMAN_BENCH_ARIAL_REGULAR', font_directory / 'arial.ttf')
BOLD_FONT = location('MERMAN_BENCH_ARIAL_BOLD', FONT.with_name('arialbd.ttf'))
PLAN = HERE / 'svg-plan.json'
PRODUCTS = ('merman', 'mmdc')
BINARY = {'merman': MER, 'mmdc': MMDC}


def environment():
    cache = HERE / 'cache'
    for var, sub in {'TEMP':'tmp', 'TMP':'tmp', 'TMPDIR':'tmp', 'PUPPETEER_TMP_DIR':'tmp',
                     'PUPPETEER_CACHE_DIR':'puppeteer', 'XDG_CACHE_HOME':'xdg', 'npm_config_cache':'npm',
                     'LOCALAPPDATA':'app-local', 'APPDATA':'app-roaming'}.items():
        path = cache / sub
        path.mkdir(parents=True, exist_ok=True)
        os.environ[var] = str(path)
    os.environ['PUPPETEER_EXECUTABLE_PATH'] = str(CHROME)
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['PUPPETEER_SKIP_DOWNLOAD'] = 'true'
    os.environ['NODE_DISABLE_COMPILE_CACHE'] = '1'


def file_hash(path):
    return sha256(path.read_bytes()).hexdigest()


def product(engine):
    if engine == 'mmdc' and not CHROME.is_file():
        raise ValueError('Set MERMAN_BENCH_CHROME to a Chrome executable')
    return cli.command_prefix(engine, str(BINARY[engine]))


def check_plan():
    plan = json.loads(PLAN.read_bytes())
    index = json.loads((HERE / 'source-index.json').read_bytes())
    if file_hash(PLAN) != index['plan_sha256'] or file_hash(HERE / 'document.md') != index['document_sha256']:
        raise ValueError('frozen plan or Markdown has changed')
    old = json.loads((HERE / 'png-plan.json').read_bytes())
    if plan['scenarios'][:2] != old['scenarios'] or [s['id'] for s in plan['scenarios'][2:]] != [SCENARIO]:
        raise ValueError('the SVG plan must retain the original two controls and the document')
    requests = plan['scenarios'][2]['requests']
    fenced = re.findall(rb'(?ms)^```mermaid\n(.*?)^```\n', (HERE / 'document.md').read_bytes())
    for req, row, body in zip(requests, index['rows'], fenced, strict=True):
        if (body != req['source'].encode() or body != (HERE / row['file']).read_bytes()
                or sha256(body).hexdigest() != row['source_sha256'] or req['expected_labels'] != row['expected_labels']):
            raise ValueError(f'contents differ: {row["file"]}')
    return requests


def native_command(engine, document, directory):
    if engine == 'merman':
        return [*product(engine), 'batch', str(document), '--output-dir', str(directory), '--format', 'svg', '--jobs', '1']
    return [*product(engine), '-i', str(document), '-o', str(directory / document.name), '-e', 'svg', '-j', '1']


def batch_outputs(directory, document, requests):
    rewritten = directory / document.name
    svgs = sorted(p.relative_to(directory).as_posix() for p in directory.rglob('*.svg'))
    summary = dict(expected=len(requests), found_svgs=svgs, rewritten=rewritten.is_file(), rows=[])
    if not rewritten.is_file():
        return {**summary, 'passed': False}
    text = rewritten.read_text(encoding='utf-8')
    links = re.findall(r'!\[[^\]]*\]\(<?([^\s)>]+\.svg)>?(?:\s+"[^"]*")?\)', text)
    headings = re.findall(r'^## (.+)$', text, re.M)
    summary['headings_in_order'] = headings == [Path(req['fixture']).name for req in requests]
    summary['no_remaining_fences'] = '```mermaid' not in text
    for req, link in zip(requests, links):
        path = (directory / link).resolve()
        if not path.is_relative_to(directory) or not path.is_file():
            summary['rows'].append(dict(fixture=req['fixture'], target=link, status='missing-asset'))
            continue
        row = dict(fixture=req['fixture'], source_sha256=req['source_sha256'], target=path.relative_to(directory).as_posix())
        try:
            row.update(cli.verify_output(path, 'svg', req['expected_labels'], 'draw'), status='ok')
        except (OSError, ValueError) as error:
            row.update(status='invalid-output', error=str(error))
        summary['rows'].append(row)
    summary['passed'] = (summary['headings_in_order'] and summary['no_remaining_fences'] and
                         len(links) == len(set(links)) == len(svgs) == len(requests) and
                         all(row['status'] == 'ok' for row in summary['rows']))
    return summary


def untimed(command, directory, timeout=120):
    result = subprocess.run(command, cwd=directory, stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout)
    return dict(returncode=result.returncode, stdout=result.stdout.decode('utf-8', 'replace')[-2200:],
                stderr=result.stderr.decode('utf-8', 'replace')[-2200:])


def fresh(directory, fmt):
    codes = []
    plan = PLAN if fmt == 'svg' else HERE / 'png-plan.json'
    for engine in PRODUCTS:
        cmd = [sys.executable, '-B', str(WORKTREE / 'tools/bench/workload_cli.py'), '--plan', str(plan),
               '--engine', engine, '--binary', str(BINARY[engine]), '--format', fmt,
               '--samples', '3', '--timeout-seconds', '60', '--output-dir', str(directory / 'files')]
        with (directory / f'{engine}-{fmt}.json').open('xb') as report:
            result = subprocess.run(cmd, cwd=WORKTREE, stdout=report, check=False)
        codes.append(result.returncode)
    return max(codes)


def native(directory, requests, smoke=False):
    document = HERE / 'document.md'
    if smoke:
        # One short flowchart and one medium sequence from different proposals.
        requests = [requests[0], requests[13]]
        document = directory / 'smoke.md'
        text = '# Kubernetes enhancement proposals\n\n' + ''.join(
            f'## {Path(r["fixture"]).name}\n\n```mermaid\n{r["source"]}```\n\n' for r in requests)
        document.write_bytes(text.encode())
    order = [PRODUCTS] if smoke else [PRODUCTS, PRODUCTS[::-1], PRODUCTS]
    rows = []
    with ThreadPoolExecutor(max_workers=1) as pool:
        for n, engines in enumerate(order, 1):
            for engine in engines:
                folder = directory / f'round-{n}-{engine}'
                folder.mkdir()
                cmd = native_command(engine, document, folder)
                result = untimed(cmd, folder) if smoke else cli.invoke(cmd, 240, folder, pool)
                rows.append(dict(round=n, engine=engine, command=cmd, result=result, output=folder.name))
    for row in rows:
        row['validation'] = batch_outputs(directory / row['output'], document, requests)
    status = all(row['result']['returncode'] == 0 and row['validation']['passed'] for row in rows)
    raw = dict(schema_version=1, operation='markdown-to-rewritten-markdown-and-all-svg-assets',
               jobs=1, parallel_documents=1, instrumented=not smoke, timed_unit='whole CLI process' if not smoke else None,
               plan_sha256=file_hash(PLAN), markdown_sha256=file_hash(document), requests=len(requests),
               process_lifecycle='one CLI process per whole document, browser descendants allowed',
               timeout_seconds=120 if smoke else 240, validation='rewritten headings, ordered link targets, distinct SVG count, per-source visible labels',
               rows=rows, all_passed=status)
    (directory / ('smoke-native.json' if smoke else 'native-batch.json')).write_bytes(encoded(raw))
    return 0 if status else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lane', choices=('fresh-svg','fresh-png','native-svg','smoke-native'))
    parser.add_argument('--out', type=Path, required=True, help='fresh directory underneath this experiment')
    args = parser.parse_args()
    environment()
    requests = check_plan()
    directory = args.out.resolve()
    if not directory.is_relative_to(HERE) or directory == HERE:
        raise ValueError('select a new subdirectory within this experiment')
    directory.mkdir(parents=True, exist_ok=False)
    if args.lane.startswith('fresh-'):
        return fresh(directory, args.lane.split('-')[1])
    return native(directory, requests, args.lane == 'smoke-native')


if __name__ == '__main__':
    sys.exit(main())
