"""Reconstruct the Kubernetes document collection at its recorded commit."""

import argparse
from collections import Counter
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import urllib.request


HERE = Path(__file__).resolve().parent
local_root = next((p for p in HERE.parents if (p / '.worktrees/workload-bench/tools/bench/workload_cli.py').is_file()), None)
if os.environ.get('MERMAN_BENCH_CHECKOUT'):
    WORKTREE = Path(os.environ['MERMAN_BENCH_CHECKOUT']).expanduser().resolve()
elif local_root:
    WORKTREE = local_root / '.worktrees/workload-bench'
else:
    WORKTREE = next((p for p in HERE.parents if (p / 'tools/bench/workload_cli.py').is_file()), None)
if not WORKTREE or not (WORKTREE / 'tools/bench/workload_cli.py').is_file():
    sys.exit('Set MERMAN_BENCH_CHECKOUT to the Merman checkout containing tools/bench/workload_cli.py (see REPRODUCE.md).')
ROOT = local_root or WORKTREE
OLD = Path(os.environ.get('MERMAN_BENCH_HISTORICAL_CLI', str(ROOT / 'target/bench/experiments/reader-comparison-20261123')))
COMMIT = '9d7081e744515d2a29e621b9189403c814d76eec'
REPO = 'https://github.com/kubernetes/enhancements'
ARCHIVE = f'https://codeload.github.com/kubernetes/enhancements/tar.gz/{COMMIT}'
SCENARIO = 'kubernetes-keps-document'
sys.path.insert(0, str(WORKTREE / 'tools/bench'))
from run_workloads import document_scenario


def encoded(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def extracted(path, raw):
    if Path(path).suffix.lower() in ('.mermaid', '.mmd'):
        yield 1, len(raw.splitlines()), 0, 'file', raw
        return
    lines = raw.splitlines(keepends=True)
    for i, line in enumerate(lines):
        opening = re.fullmatch(rb'( *)```mermaid[ \t]*(?:\r?\n|$)', line)
        if not opening:
            continue
        indent = opening[1]
        end = next(j for j in range(i + 1, len(lines))
                   if re.fullmatch(indent + rb'```[ \t]*(?:\r?\n|$)', lines[j]))
        body = b''.join(line.removeprefix(indent) for line in lines[i + 1:end])
        yield i + 1, end + 1, len(indent), 'fence', body


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('--check', action='store_true', help='compare with frozen bytes, without writing')
    args.add_argument('--download', action='store_true', help='download the immutable snapshot if absent')
    options = args.parse_args()
    archive = HERE / 'cache/keps.tar.gz'
    if not archive.is_file() and options.download:
        archive.parent.mkdir(exist_ok=True)
        with urllib.request.urlopen(ARCHIVE, timeout=90) as response:
            archive.write_bytes(response.read())

    def emit(name, raw):
        path = HERE / name
        if options.check:
            if path.read_bytes() != raw:
                raise ValueError(f'frozen bytes differ: {name}')
        else:
            path.parent.mkdir(exist_ok=True, parents=True)
            path.write_bytes(raw)

    docs = {}
    scanned = 0
    with tarfile.open(archive, 'r|gz') as tar:
        for member in tar:
            root, _, path = member.name.partition('/')
            if root != f'enhancements-{COMMIT}':
                raise ValueError('unexpected archive root')
            if not member.isfile():
                continue
            if path in ('LICENSE', 'NOTICE'):
                emit(f'upstream-{path}.txt', tar.extractfile(member).read())
            if (re.match(r'^keps/sig-[^/]+/[0-9]+-[^/]+/', path)
                    and Path(path).suffix.lower() in ('.md', '.mmd', '.mermaid')):
                scanned += 1
                raw = tar.extractfile(member).read()
                matches = list(extracted(path, raw))
                if matches:
                    docs[path] = (raw, matches)

    facts = json.loads((HERE / 'reviewed-labels.json').read_bytes())
    sources, labels, duplicates, seen = [], {}, [], {}
    for path, (raw, matches) in sorted(docs.items()):
        for first, last, indent, kind, body in matches:
            canonical = body.replace(b'\r\n', b'\n')
            if not canonical.endswith(b'\n'):
                canonical += b'\n'
            key = sha256(b'\n'.join(line.rstrip(b' \t') for line in canonical.split(b'\n')).strip(b'\n')).hexdigest()
            ref = f'{path}#L{first}-L{last}'
            if key in seen:
                duplicates.append(dict(occurrence=ref, retained=seen[key]))
                continue
            seen[key] = ref
            family = re.search(rb'(?m)^\s*(flowchart|sequenceDiagram|stateDiagram-v2|gantt)\b', canonical)[1].decode()
            family = {'sequenceDiagram': 'sequence', 'stateDiagram-v2': 'state'}.get(family, family)
            kep = path.split('/')[2].split('-')[0]
            basename = Path(path).stem if kind == 'file' else f'L{first}'
            name = f'sources/{len(sources) + 1:02d}-kep-{kep}-{basename}.mmd'
            display = facts[f'{kep}/{basename}']
            if len(display) < 2 or len(set(display)) != len(display):
                raise ValueError(f'incomplete reviewed facts for {ref}')
            lines = len(canonical.splitlines())
            sources.append(dict(file=name, path=path, first_line=first, last_line=last,
                                kind=kind, markdown_indent=indent, upstream_file_sha256=sha256(raw).hexdigest(),
                                extracted_body_sha256=sha256(body).hexdigest(), terminal_lf_added=not body.endswith(b'\n'),
                                upstream_url=f'{REPO}/blob/{COMMIT}/{ref}', source_sha256=sha256(canonical).hexdigest(),
                                dedup_sha256=key, bytes=len(canonical), lines=lines, family=family,
                                size_band='small' if lines < 10 else 'medium' if lines < 30 else 'large',
                                expected_labels=display))
            emit(name, canonical)
            labels[name] = display
    if len(sources) != len(facts) or not 20 <= len(sources) <= 50:
        raise ValueError('selection and reviewed facts differ')
    manifest = dict(id=SCENARIO, origin=f'{REPO}/tree/{COMMIT}/keps (collection of numbered proposals and companion diagram files, in path and document order)',
                    files=list(labels), expected_labels=labels)
    emit('document-manifest.json', encoded(manifest))
    document = document_scenario(HERE / 'document-manifest.json')
    legacy = (HERE / 'png-plan.json').read_bytes() if (HERE / 'png-plan.json').exists() else (OLD / 'cli-plan.json').read_bytes()
    emit('png-plan.json', legacy)
    plan = json.loads(legacy)
    if [s['id'] for s in plan['scenarios']] != ['family-flowchart', 'family-sequence']:
        raise ValueError('unexpected legacy single-diagram plan')
    plan['scenarios'].append(document)
    emit('svg-plan.json', encoded(plan))
    parts = [b'# Kubernetes enhancement proposals\n\n']
    for src, request in zip(sources, document['requests'], strict=True):
        body = request['source'].encode('utf-8')
        if sha256(body).hexdigest() != src['source_sha256']:
            raise ValueError(f'plan materialization changed {src["file"]}')
        if not body.endswith(b'\n') or b'```' in body:
            raise ValueError('a frozen source requires a different Markdown fence')
        parts.extend([f'## {src["file"].split("/")[-1]}\n\n'.encode(), b'```mermaid\n', body, b'```\n\n'])
    emit('document.md', b''.join(parts))
    summary = dict(repository=REPO, commit=COMMIT, archive_url=ARCHIVE, snapshot_selection='last master commit before 2025-12-01 00:00:00 UTC',
                   source_selection='All literal triple-backtick mermaid fences in .md (including nested collapsible sections), and all .mmd/.mermaid files underneath numbered keps/sig-*/ directories. Case-insensitive file extensions. Sort by upstream path, then block order. Retain the first canonical body.',
                   normalization='Strip only the opening Markdown indentation from each body line when present, normalize CRLF to LF, and add one LF only to a source missing its final newline so the single-file and fenced inputs agree. For deduplication only, also strip terminal blanks on each line and outer blank lines. Markdown coordinates include both fences.',
                   size_definition='Physical source lines including the diagram header, blank lines and configuration: small 1-9, medium 10-29, large 30+. This is input length, not graph cardinality.',
                   scanned_files=scanned, contributing_files=len(docs), proposals=len({p.split('/')[2] for p in docs}),
                   occurrences=len(sources) + len(duplicates), distinct=len(sources), duplicates=duplicates,
                   family_counts=Counter(s['family'] for s in sources), size_counts=Counter(s['size_band'] for s in sources),
                   occurrence_types=Counter(s['kind'] for s in sources), visible_label_facts=sum(map(len, labels.values())),
                   document_sha256=sha256(b''.join(parts)).hexdigest(), plan_sha256=sha256(encoded(plan)).hexdigest(),
                   rows=sources)
    emit('source-index.json', encoded(summary))
    print(json.dumps({k: v for k, v in summary.items() if k in ('distinct','scanned_files','proposals','contributing_files','size_counts','family_counts','visible_label_facts','plan_sha256')}))


if __name__ == '__main__':
    main()
