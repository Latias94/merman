# Kubernetes enhancement proposals

## 01-kep-4355-L308.mmd

```mermaid
flowchart TD
   A[Reconcile] --> |Process Leader Lease| B
   B{Lease Status?} --> |Better Leader Exists| D
   B --> |Expired/Missing| E
   D[End Lease Term]
   E[Elect Leader]
```

## 02-kep-4355-L364.mmd

```mermaid
flowchart TD
    A[Started] -->|Create LeaseCandidate Lease| B
    B[Candidate] --> |Elected| C[Leader]
    C --> |Renew Leader Lease| C
    C -->|Better Candidate Available / Leader Lease Expired| D[Yield Leadership]
    D[Yield Leadership] -.-> |Shutdown/Restart if necessary| A
```

## 03-kep-3998-L383.mmd

```mermaid
stateDiagram-v2
    [*] --> Running
    Running --> FailureTarget: Exceeded backoffLimit
    Running --> FailureTarget: Exceeded activeDeadlineSeconds
    Running --> FailureTarget: Matched FailurePolicy with action=FailJob
    FailureTarget --> Failed: All pods are terminated
    Failed --> [*]
    Running --> SuccessCriteriaMet: Matched SuccessPolicy
    Running --> SuccessCriteriaMet: Achieved the expected completions
    SuccessCriteriaMet --> Complete: All pods are terminated
    Complete --> [*]
```

## 04-kep-3998-L978.mmd

```mermaid
stateDiagram-v2
    [*] --> Running
    Running --> Failed: Exceeded backoffLimit
    Running --> FailureTarget: Matched FailurePolicy with action=FailJob
    FailureTarget --> Failed: All pods are terminated
    Failed --> [*]
    Running --> SuccessCriteriaMet: Matched SuccessPolicy
    Running --> SuccessCriteriaMet: Matched SuccessPolicy
    SuccessCriteriaMet --> SuccessCriteriaMet: Wait for all pods are finalized
    SuccessCriteriaMet --> Complete: All pods are finished
    Complete --> [*]
```

## 05-kep-3935-L121.mmd

```mermaid
gantt
    dateFormat  YYYY-MM-DD
    axisFormat  %Y-%m

    section Releases

    v1.40 supported :    140support, 2030-04-01, 2031-06-01
    v1.41 supported... : 141support, 2030-08-01, 2031-07-01
    v1.42 supported... : 142support, 2030-12-01, 2031-07-01
    v1.43 supported... : 143support, 2031-04-01, 2031-07-01

    section with n-3
    Qualify v1.40                                     : n3_140qual,        2030-04-01,4w
    Run v1.40                                         : n3_140run,         after n3_140qual, 1y
    Qualify v1.41/v1.40                               : n3_143qual1,       2031-04-01,4w
    Qualify v1.42/v1.40                               : n3_143qual2,       2031-04-01,4w
    Qualify v1.43/v1.40                               : n3_143qual3,       2031-04-01,4w
    Qualify v1.43                                     : n3_143qual,        2031-04-01,4w
    Control Plane → v1.41 → v1.42 → v1.43             : n3_143cpupgrade,   after n3_143qual, 1d
    Nodes → v1.43 (drain/recreate workloads)          : n3_143nodeupgrade, after n3_143cpupgrade,  1w
    Run v1.43...                                      : n3_143run,         after n3_143nodeupgrade, 2031-07-01

    section with n-2
    Qualify v1.40                                     : n2_140qual,        2030-04-01,4w
    Run v1.40                                         : n2_140run,         after n2_140qual, 1y
    Qualify v1.41/v1.40                               : n3_143qual1,       2031-04-01,4w
    Qualify v1.42/v1.40                               : n3_143qual2,       2031-04-01,4w
    Qualify v1.42                                     : n3_143qual3,       2031-04-01,4w
    Qualify v1.43/v1.42                               : n3_143qual4,       2031-04-01,4w
    Qualify v1.43                                     : n2_143qual,        2031-04-01,4w
    Control Plane → v1.41 → v1.42                     : n2_142cpupgrade,   after n2_143qual, 1d
    Nodes → v1.42 (drain/recreate workloads)          : n2_142nodeupgrade, after n2_142cpupgrade,  1w
    Control Plane → v1.43                             : n2_143cpupgrade,   after n2_142nodeupgrade,  1d
    Nodes → v1.43 (drain/recreate workloads)          : n2_143nodeupgrade, after n2_143cpupgrade,  1w
    Run v1.43...                                      : n2_143run,         after n2_143nodeupgrade, 2031-07-01
```

## 06-kep-3299-L285.mmd

```mermaid
%%{init:{"sequence": {"mirrorActors":true},
    "themeVariables": {
        "actorBkg":"royalblue",
        "actorTextColor":"white"
}}}%%

sequenceDiagram
    participant user
    participant kube_api_server
    participant kms_plugin
    participant external_kms
    alt Generate DEK seed at startup
        Note over kube_api_server,external_kms: Refer to Generate Data Encryption Key (DEK) Seed diagram for details
    end
    user->>kube_api_server: create/update resource that's to be encrypted
    kube_api_server->>kube_api_server: generate DEK using DEK seed
    kube_api_server->>kube_api_server: encrypt resource with DEK
    kube_api_server->>etcd: store encrypted object
```

## 07-kep-3299-L308.mmd

```mermaid
%%{init:{"sequence": {"mirrorActors":true},
    "themeVariables": {
        "actorBkg":"royalblue",
        "actorTextColor":"white"
}}}%%

sequenceDiagram
    participant user
    participant kube_api_server
    participant kms_plugin
    participant external_kms
    participant etcd
    user->>kube_api_server: get/list resource that's encrypted
    kube_api_server->>etcd: get encrypted resource
    etcd->>kube_api_server: encrypted resource
    alt Encrypted DEK seed not in cache
        kube_api_server->>kms_plugin: decrypt request
        kms_plugin->>external_kms: decrypt DEK seed with remote KEK
        external_kms->>kms_plugin: decrypted DEK seed
        kms_plugin->>kube_api_server: return decrypted DEK seed
        kube_api_server->>kube_api_server: cache decrypted DEK seed
    end
    kube_api_server->>kube_api_server: generate DEK using DEK seed
    kube_api_server->>kube_api_server: decrypt resource with DEK
    kube_api_server->>user: return decrypted resource
```

## 08-kep-3299-L338.mmd

```mermaid
%%{init:{"sequence": {"mirrorActors":true},
    "themeVariables": {
        "actorBkg":"royalblue",
        "actorTextColor":"white"
}}}%%

sequenceDiagram
    participant kube_api_server
    participant kms_plugin
    participant external_kms
    alt Generate DEK seed at startup
        Note over kube_api_server,external_kms: Refer to Generate Data Encryption Key (DEK) Seed diagram for details
    end
    loop every minute (or every 10s if error or unhealthy)
        kube_api_server->>kms_plugin: status request
        kms_plugin->>external_kms: validate remote KEK
        external_kms->>kms_plugin: KEK status
        kms_plugin->>kube_api_server: return status response <br/> {"healthz": "ok", key_id: "<remote KEK ID>", "version": "v2beta1"}
        alt KEK rotation detected (key_id changed), rotate DEK seed
            Note over kube_api_server,external_kms: Refer to Generate Data Encryption Key (DEK) Seed diagram for details
        end
    end
```

## 09-kep-3299-L365.mmd

```mermaid
%%{init:{"sequence": {"mirrorActors":true},
    "themeVariables": {
        "actorBkg":"royalblue",
        "actorTextColor":"white"
}}}%%

sequenceDiagram
    participant kube_api_server
    participant kms_plugin
    participant external_kms
        kube_api_server->>kube_api_server: generate DEK seed
        kube_api_server->>kms_plugin: encrypt request
        kms_plugin->>external_kms: encrypt DEK seed with remote KEK
        external_kms->>kms_plugin: encrypted DEK seed
        kms_plugin->>kube_api_server: return encrypt response <br/> {"ciphertext": "<encrypted DEK seed>", key_id: "<remote KEK ID>", "annotations": {}}
```

## 10-kep-3299-L395.mmd

```mermaid
stateDiagram-v2
KEK
note right of KEK
   accessed via plugin
end note
KEK --> DEK_seed: encrypts
DEK_seed --> etcd: Encrypted_DEK_seed stored
```

## 11-kep-3299-L405.mmd

```mermaid
stateDiagram-v2
etcd_path
note left of etcd_path
   unique per object in etcd
   /PATH_PREFIX/secrets/NAMESPACE/NAME
end note
resource
note right of resource
   stored in EncryptedObject.EncryptedData as
   info|nonce|ciphertext
end note
DEK_seed --> hkdf_expand: pseudo random key
sha256 --> hkdf_expand: hash
rand_nonce_32 --> hkdf_expand: info param
hkdf_expand --> DEK: generates
DEK --> aes_gcm: key
rand_nonce_12 --> aes_gcm: nonce
etcd_path --> aes_gcm: additional_data
aes_gcm --> resource: encrypts
```

## 12-kep-3299-L765.mmd

```mermaid
sequenceDiagram
    participant etcd
    participant kubeapiserver
    participant kmsplugin
    participant externalkms
    kubeapiserver->>kmsplugin: encrypt request
    alt using key hierarchy
        kmsplugin->>kmsplugin: encrypt DEK with local KEK
        kmsplugin->>externalkms: encrypt local KEK with remote KEK
        externalkms->>kmsplugin: encrypted local KEK
        kmsplugin->>kmsplugin: cache encrypted local KEK
        kmsplugin->>kubeapiserver: return encrypt response <br/> {"ciphertext": "<encrypted DEK>", key_id: "<remote KEK ID>", <br/> "annotations": {"kms.kubernetes.io/local-kek": "<encrypted local KEK>"}}
    else not using key hierarchy
        %% current behavior
        kmsplugin->>externalkms: encrypt DEK with remote KEK
        externalkms->>kmsplugin: encrypted DEK
        kmsplugin->>kubeapiserver: return encrypt response <br/> {"ciphertext": "<encrypted DEK>", key_id: "<remote KEK ID>", "annotations": {}}
    end
    kubeapiserver->>etcd: store encrypt response and encrypted DEK
```

## 13-kep-3299-L792.mmd

```mermaid
sequenceDiagram
    participant kubeapiserver
    participant kmsplugin
    participant externalkms
    %% if local KEK in annotations, then using hierarchy
    alt encrypted local KEK is in annotations
      kubeapiserver->>kmsplugin: decrypt request <br/> {"ciphertext": "<encrypted DEK>", key_id: "<key_id gotten as part of EncryptResponse>", <br/> "annotations": {"kms.kubernetes.io/local-kek": "<encrypted local KEK>"}}
        alt encrypted local KEK in cache
            kmsplugin->>kmsplugin: decrypt DEK with local KEK
        else encrypted local KEK not in cache
            kmsplugin->>externalkms: decrypt local KEK with remote KEK
            externalkms->>kmsplugin: decrypted local KEK
            kmsplugin->>kmsplugin: decrypt DEK with local KEK
            kmsplugin->>kmsplugin: cache decrypted local KEK
        end
        kmsplugin->>kubeapiserver: return decrypt response <br/> {"plaintext": "<decrypted DEK>", key_id: "<remote KEK ID>", <br/> "annotations": {"kms.kubernetes.io/local-kek": "<encrypted local KEK>"}}
    else encrypted local KEK is not in annotations
        kubeapiserver->>kmsplugin: decrypt request <br/> {"ciphertext": "<encrypted DEK>", key_id: "<key_id gotten as part of EncryptResponse>", <br/> "annotations": {}}
        kmsplugin->>externalkms: decrypt DEK with remote KEK (same behavior as today)
        externalkms->>kmsplugin: decrypted DEK
        kmsplugin->>kubeapiserver: return decrypt response <br/> {"plaintext": "<decrypted DEK>", key_id: "<remote KEK ID>", <br/> "annotations": {}}
    end
```

## 14-kep-4317-L512.mmd

```mermaid
sequenceDiagram
    participant kubelet as kubelet
    participant api as kube-apiserver
    participant signer as signer

    note over kubelet: Begin projected volume setup
    kubelet->api: Create PodCertificateRequest X
    note over api: Enforce node restriction
    api->signer: See PodCertificateRequest X
    note over signer: Decide whether or not to issue certificate
    signer->api: Update /status<br>Set CertificateChain, BeginRefreshAt
    kubelet->api: See PodCertificateRequest X issued
    note over kubelet: Write credential bundle to pod filesystem

    note over kubelet: Pod starts
    
    
    loop While pod is running
      note over kubelet: BeginRefreshAt time reached
      kubelet->api: Create PodCertificateRequest Y
      note over api: Enforce node restriction
      api->signer: See PodCertificateRequest Y
      note over signer: Decide whether or not to issue certificate
      signer->api: Update /status<br>Set CertificateChain, BeginRefreshAt
      kubelet->api: See PodCertificateRequest Y issued
      note over kubelet: Write credential bundle to pod filesystem
    end 
```

## 15-kep-5018-L296.mmd

```mermaid
flowchart TD
    AA[Pod needs ResourceClaim for ResourceClaimTemplate] --> AB{adminAccess: true?}
    AB -- No --> A
    AB -- Yes --> AC{feature enabled?}
    AC -- No --> AY[refuse to create ResourceClaim, Pod remains pending]
    AC -- Yes --> A
    A[Request to API server to Create/Update ResourceClaim or ResourceClaimTemplate] --> B{adminAccess: true and feature enabled?}
    B -- No --> E
    B -- Yes --> D[Check Namespace Label]
    D -- Label Present --> E[Request Allowed]
    D -- No Label --> F[Request Rejected]
    E --> G[Resource Created/Updated]
    G --> H[Kubernetes Scheduler evaluates ResourceClaim]
    H -- Admin Access Devices --> I[Skip allocation checks; Device is not allocated]
    H -- Standard Claims --> J[Proceed with standard allocation checks]
    J --> K
    I --> K
    K[kubelet asks DRA driver to prepare the ResourceClaim] --> L
    L[DRA driver reads full ResourceClaim] --> M
    M[DRA driver may grant additional permissions for devices with admin access]
```

## 16-kep-5284-L362.mmd

```mermaid
flowchart TD
  A[receive request] --> |feature enabled| B{Identify the target user via impersonation header}
  B --> |Impersonate-User has the prefix of system:node:|C{The requester is on the same node}
  C --> |yes| D{Requester is authorized to impersonate the target action with impersonate-on:associated-node:< verb >}
  C --> |no| E{Requester is authorized to impersonate the target action with impersonate-on:arbitrary-node:< verb >}
  D --> |yes| F{Requester is authorized to impersonate the target user/uid/groups/extra with impersonate:< mode >}
  D --> |no| E
  E --> |yes| F
  E --> |no| H
  F -->|yes| G[Allow]
  A -->|feature disable| H{Requester has the legacy impersonate permission}
  H -->|yes| G
  F -->|no| H
  B --> |Impersonate-User has the prefix of system:serviceaccount:| I{Requester is authorized to impersonate the target action with impersonate-on:serviceaccount:< verb >}
  I --> |yes| F
  I --> |no| H
  B --> |Impersonate-User does not have the prefix of system:serviceaccount: or system:node:| J{Requester is authorized to impersonate the target action with impersonate-on:user-info:< verb >}
  J --> |yes|F
  J --> |no|H
```

## 17-kep-5681-L10.mmd

```mermaid
---
config:
  layout: elk
title: Kubernetes with Conditional Authorization
---
flowchart LR
 subgraph ChainAuthorizer["ChainAuthorizer"]
    direction TB
        AuthzAllow["Allow"]
        AuthzConditional["Conditional"]
        AuthzDeny["Deny"]
        AuthzNoOpinion["NoOpinion"]
  end
 subgraph WithAuthorization["WithAuthorization"]
    direction TB
        ServeHTTP["ServeHTTP"]
        ServeHTTPWithConditions["ServeHTTP + ctx conditions"]
        CannotBecomeAuthz["CannotBecomeAuthz"]
  end
 subgraph ChainAuthorizerEval["ChainAuthorizerEval"]
        NoOpinion2["NoOpinion"]
        Allow2["Allow"]
        Conditional2["Conditional"]
        Deny2["Deny"]
  end
 subgraph ValidatingAdmission["ValidatingAdmission"]
    direction TB
        AdmissionAllow["Allow"]
        AdmissionEvaluate["Evaluate"]
        AdmissionNoOpinion["NoOpinion"]
        AdmissionDeny["Deny"]
        ChainAuthorizerEval
  end
    Request["Request"] --> ChainAuthorizer
    AuthzNoOpinion --> Request
    AuthzAllow --> ServeHTTP
    ServeHTTPWithConditions --> AdmissionEvaluate
    AdmissionEvaluate --> AdmissionNoOpinion & AdmissionAllow & AdmissionDeny
    AdmissionNoOpinion --> ChainAuthorizerEval
    NoOpinion2 --> AdmissionNoOpinion
    Allow2 --> AdmissionAllow
    Conditional2 --> AdmissionEvaluate
    Deny2 --> AdmissionDeny
    AdmissionDeny --> 403(["403"])
    ServeHTTP -- Allowed --> AdmissionAllow["Allow"]
    AuthzConditional -- 1+ Allow --> ServeHTTPWithConditions
    AuthzConditional -- 0 Allow --> CannotBecomeAuthz
    AuthzDeny --> CannotBecomeAuthz
    CannotBecomeAuthz --> 403
    AdmissionAllow --> Storage(["Storage"])
```

## 18-kep-2535-L348.mmd

```mermaid
sequenceDiagram
    participant A as Pod A
    participant kubelet
    participant CRI
    participant imagemanager as ImagePullManager

    A->>kubelet: request ("img:tag", secret A)
    kubelet->>CRI: request imgRef("img:tag")
    rect rgb(253, 253, 190)
    alt image not present
        CRI->>kubelet: <nil>
    else image present but not in cache + must be verified by policy
        CRI->>kubelet: imgRef("img:tag")
        kubelet->>imagemanager: MustAttemptImagePull("img:tag", imgRef("img:tag"), { secret A })
        imagemanager->>imagemanager: policy("img:tag") -> verify
        imagemanager->>imagemanager: getRecord(imgRef("img:tag"), { secret A }) -> nil
        imagemanager->>kubelet: true
    end
    end

    note left of imagemanager: the image might actually already<br/>be in pending pull here
    kubelet->>imagemanager: RecordPullIntent("img:tag")
    imagemanager->>imagemanager: storePulling("img:tag") -> refCount("img:tag")++

    rect rgb(189, 245, 252)
    alt pull failed
        CRI->>kubelet: pull failed
        kubelet->>imagemanager: RecordImagePullFailed("img:tag")
        imagemanager->>imagemanager: deletePulling("img:tag") -> refCount("img:tag")--
        alt refCount("img:tag") == 0
            imagemanager->>imagemanager: destroyPulling("img:tag")
        end
        kubelet->>A: ImagePullFailed
    else pull successful
        CRI->>kubelet: imgRef("img:tag")
        kubelet->>imagemanager: RecordImagePulled("img:tag", imgRef("img:tag"), { secret A })
        imagemanager->>imagemanager: storePulled(imgRef("img:tag"), { secret A })
        imagemanager->>imagemanager: destroyPulling("img:tag")

        kubelet->>A: continue starting pod
    end
    end
```

## 19-kep-2535-L396.mmd

```mermaid
sequenceDiagram
    participant A as Pod A
    participant kubelet
    participant CRI
    participant imagemanager as ImagePullManager

    A->>kubelet: request ("img:tag", secret A)
    kubelet->>CRI: request imgRef("img:tag")
    CRI->>kubelet: imgRef("img:tag")
    kubelet->>imagemanager: MustAttemptImagePull("img:tag", imgRef("img:tag"), { secret A })
    rect rgb(253, 253, 190)
    alt image present and set not to verify
        imagemanager->>imagemanager: policy("img:tag") -> no-verify
        imagemanager->>kubelet: false
    else image present in cache
        imagemanager->>imagemanager: policy("img:tag") -> verify
        imagemanager->>imagemanager: getRecord(imgRef("img:tag"), { secret A }) -> { record }
        imagemanager->>kubelet: false
    end
    end
    kubelet->>A: continue starting pod
```

## 20-kep-3386-evented-pleg.mmd

```mermaid
sequenceDiagram
    Title: Evented PLEG
    Runtime-->>+Evented PLEG: Send CRI Event
    Evented PLEG-->>Evented PLEG: Generate PodStatus from received Event
    Evented PLEG-->>Evented PLEG: Set pod cache update time to the Event creation time
    Evented PLEG-->>Evented PLEG: Update the PodStatus in the cache
    Evented PLEG-->>PLEG Channel: Send PodLifeCycleEvent
```

## 21-kep-3386-existing-generic-pleg.mmd

```mermaid
sequenceDiagram
    Title: Existing Generic PLEG
    Generic PLEG-->>Generic PLEG: Global cache update timestamp = time.Now()
    Generic PLEG->>+Runtime: GetPods()
    Runtime-->>-Generic PLEG: List of Pods
    Generic PLEG-->>Generic PLEG: Generate PodLifeCycleEvents for updated Pods
    loop EventsbyPodID
        Generic PLEG-->>Generic PLEG: Pod cache update timestamp = time.now()
        Generic PLEG->>+Runtime: Get Sandbox Statuses 
        Runtime-->>-Generic PLEG: 
        Generic PLEG->>+Runtime: Get Container Statuses 
        Runtime-->>-Generic PLEG: 
        Generic PLEG-->>Generic PLEG: Update the PodStatus in the cache
        Generic PLEG-->>PLEG Channel: Send PodLifeCycleEvent
    end
```

## 22-kep-3386-modified-cache-setter.mmd

```mermaid
sequenceDiagram
    Title: Modified Cache Setter
    Evented PLEG->>Cache: Set PodStatus
    Generic PLEG->>Cache: Set PodStatus
    Note over  Cache: Update the PodStatus only if it is newer than Cache
```

## 23-kep-3386-modified-generic-pleg.mmd

```mermaid
sequenceDiagram
    Title: Modified Generic PLEG
    Generic PLEG-->>Generic PLEG: Global cache update timestamp = time.Now()
    Generic PLEG->>+Runtime: GetPods()
    Runtime-->>-Generic PLEG: List of Pods
    Generic PLEG-->>Generic PLEG: Generate PodLifeCycleEvents for updated Pods
    loop EventsbyPodID
        Generic PLEG-->>+Runtime: PodSandboxStatus(includeContainers=true)
        Runtime->>Runtime: Get Sandbox Status
        Runtime->>Runtime: Get Container Statuses
        Runtime->>Runtime: timestamp = time.now()
        Runtime-->>-Generic PLEG:
        Generic PLEG-->>Generic PLEG: Update the PodStatus in the cache
        Generic PLEG-->>PLEG Channel: Send PodLifeCycleEvent
    end
```

## 24-kep-4639-L536.mmd

```mermaid
sequenceDiagram
    participant K as kubelet
    participant C as Container Runtime
    Note left of K: During pod sync
    Note over K,C: CRI
    K->>+C: RPC: PullImage
    Note right of C: Pull OCI object
    C-->>-K: PullImageResponse.image_ref
    Note left of K: Add mount points<br/> to container<br/>creation request
    K->>+C: RPC: CreateContainer
    Note right of C: Mount OCI object
    Note right of C: Add OCI bind mounts<br/>from OCI object<br/>to container
    C-->>-K: CreateContainerResponse
```

## 25-kep-1731-L407.mmd

```mermaid
flowchart
    Authenticate --> Checkout[Checkout/Clone packages]
    Checkout --> Gen[Generate specs and sources]
    Gen --> Push[Push changes to OBS]
    Push --> Wait[Wait for builds]
    Wait --> Release[Release builds]
```

