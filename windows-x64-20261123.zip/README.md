# Public renderer benchmark evidence · Windows x64 · 2026-11-23

This archive contains the frozen inputs, per-worker samples, retained outputs, product identities and collection settings behind the Windows report. The host used an Intel Core i7-11700, Node 26.4.0 and Python 3.12.10. `SHA256SUMS` covers every other member. Absolute installation paths and the host name use portable aliases, and process output excerpts are omitted. `original-report-sha256.json` identifies the original JSON files where this metadata changed. Input plans, dependencies' lockfiles, SVGs, PNGs and measured numbers retain their recorded values.

Use the benchmark code from the publication revision referenced by the report. The packages measured in Node were `@mermanjs/node@0.11.0` (N-API), `pele@1.13.0` and `mermaid@13.0.0-alpha.3`. Node drawing checks and mmdc used Chrome 157 on this host. The separate Playground corpus used Headless Chromium 158 and `@mermanjs/web@0.11.0`, with Mermaid.js 12.3.0. The native topology runner identifies its local build and binary hash in `rust/work.json`.

## Recompute the report

Extract the archive and run the following from the benchmark checkout. The `--note` option in the published receipt contains the snapshot's editorial notes. The script below carries those notes forward when recomputing the measurements. Save the Markdown and adjacent JSON from the published report in one directory first.

```python
import json, pathlib, subprocess, sys, tempfile

evidence = pathlib.Path("/path/to/extracted-evidence")
published = pathlib.Path("/path/to/2026-11-23-windows-x64.json")
receipt = json.loads(published.read_bytes())
runner = [sys.executable, "-B", "tools/bench/perf_runner.py", "workloads", "report"]
with tempfile.TemporaryDirectory() as temp:
    out = pathlib.Path(temp) / published.with_suffix(".md").name
    subprocess.run([*runner, "--date", receipt["date"], "--note", receipt["note"],
        "--raw-url", receipt["raw_url"], "--node-matrix", evidence / "node-coverage",
        "--node-rounds", evidence / "node-rounds", "--browser", evidence / "browser/corpus.json",
        "--cli", evidence / "cli/svg/plan.json", evidence / "cli/svg/merman.json", evidence / "cli/svg/mmdc.json",
        "--cli", evidence / "cli/png/plan.json", evidence / "cli/png/merman.json", evidence / "cli/png/mmdc.json",
        "--rust-work", evidence / "rust/plan.json", evidence / "rust/work.json", "--out", out], check=True)
    assert json.loads(out.with_suffix(".json").read_bytes()) == receipt
    assert out.read_text(encoding="utf-8") == published.with_suffix(".md").read_text(encoding="utf-8")
```

On platforms with `sha256sum`, run `sha256sum -c SHA256SUMS` at the archive root. The checked-in benchmark tests also exercise failed outputs, missing product identity and incomplete rounds.

## Inspect a measurement

- `node-coverage` contains the earlier 145-request coverage survey. `node-rounds` contains 12 timed scenarios. Each `rounds/NNN/<engine>.json` contains cold results, all five warm batches and per-call results. Compare worker medians within the same round. `process-rounds.json` records product order. The frozen plan preserves source bytes, diagram IDs, declared drawing properties and the number of distinct sources. `drawings` retains the final warm SVGs for declared cases. The editor case contains a deliberate rejection. Inspect its returned drawings separately from its complete-batch ratio.
- `visual-sample` contains two fixed source cases, six previews, the test program, its protocol and recorded geometry and pixel observations. Run the program against `node-rounds` using a Chromium executable and the `tools/mermaid-cli` dependencies from the checkout. The output hashes bind the six SVGs to the last warm sample in round 1.
- `cli/svg` contains the fresh-process SVG exports and `cli/png` the two historical default PNG comparisons. `cli/native` stores all three one-command Markdown document runs per engine with their rewritten documents and 25 SVG assets per run. `cli/png-controls` contains the separate font, long-edge and scale experiment, its observed dimensions and outputs. The CLI stock defaults and these controlled outputs have different raster contracts. `cli/source-index.json`, `cli/document.md` and `cli/sources` describe the anthology reconstructed from 12 Kubernetes enhancement proposals. The frozen sources include the upstream license.
- `browser/corpus.json` records individual traces, the viewport, the explicit warmup/sample schedule, engine versions and quality checks. The recorded loopback URL identifies the locally served static asset. `browser/npm-identity.json` provides its digest and the official npm tarball integrity. `rust` records the separate 32-topology stress population and exact charged-work boundaries.

## Collect fresh observations

Install the exact Node product consumer using `npm ci --prefix tools/bench/node-reference` and install the drawing observer dependencies using `npm ci --prefix tools/mermaid-cli`. Supply an installed Chrome via `--chrome`. From the checkout, run the following with the extracted `node-rounds/plan.json` and a fresh output directory.

```console
python tools/bench/perf_runner.py workloads node-matrix --plan /path/to/node-rounds/plan.json --samples 5 --process-rounds 8 --check-drawings --chrome /path/to/chrome --out-dir target/bench/new-node-rounds
```

For the CLI, set `MERMAN_BENCH_CHECKOUT`, `MERMAN_BENCH_CLI`, `MERMAN_BENCH_MMDC` and `MERMAN_BENCH_CHROME` to the checkout, official Merman CLI, installed mmdc launcher and Chrome executable. Install `tools/bench/requirements-png.txt` for the PNG observer. From `cli/`, run `python collect.py fresh-svg --out replay/fresh-svg` or `python collect.py native-svg --out replay/native-svg` followed by `python audit.py fresh replay/fresh-svg` or `python audit.py native replay/native-svg`. The portable input manifests and extracted charts are included. `cli/native/native-batch.json` contains the per-round invocation, wall time and output inspection with one job per document. Each product's timing used independent observations on this host. Other operating systems and font installations can produce different pixels and timings.
