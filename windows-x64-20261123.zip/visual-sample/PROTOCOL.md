# Readability spot check · 23 November 2026

## Frozen sample

Both cases use round `001` of the `reader-credibility-20261123/node-rounds` bundle. The sample takes the first occurrence of the repeated chain and the existing issue guide's horizontal two-subgraph example. Each SVG is the saved output of the last warm batch. Indices are zero-based. The same plan request supplies the three engines in each row.

| Scenario and fixture | Indices | Source SHA-256 | Expected graph |
| --- | --- | --- | --- |
| `four-node-repeat` / `four-node-repeat-1` | `6, 0` | `08cd16e84d5b2d8147724951612814609dda754c0ab175dcf2f7b56d6e7ee88b` | `A0[Plan0] → B0[Edit0] → C0[Test0] → D0[Ship0]`, top to bottom |
| `merman-issue-guide` / `block-4` | `11, 3` | `d4f6b38f11445ef7ef4f1c5618d22ca107e07a86ea02f5786f7c3550d33c8de1` | `L[Lint] → T[Test] → S[Staging] → P[Prod]`, left to right. `CI` contains `L,T` and `Deploy` contains `S,P`. Both titles are checked. |

The frozen `plan.json` SHA-256 is `cfec188528d1ee06b8e58e38fbdd3a678c12040b9891f2420c8234056a43fa3c`. The observer checks the source bytes, diagram ID, artifact name, last warm output size and SHA-256 against the plan and the three workers before opening any SVG. Original SVGs are under `rounds/001/drawings/<engine>/{6-0,11-3}.svg`.

| Engine | `6-0.svg` SHA-256 | `11-3.svg` SHA-256 |
| --- | --- | --- |
| `merman` | `4865cccf72fa9752029a7f3816c26304fe00af36f1142efebe82ef5c602e83d6` | `4606091735a66ba75cd1cf987c61b5ffd26e569b694ab3b0fea42fd514bdebed` |
| `pele` | `8142f97ecc1ab6a903f7a87feae23c86f7921d61e249e897ae4b117ec18f566a` | `6863ab9fa51575a59bec050b9a3cf3191216278a9ef9f097ad11e9f936436a59` |
| `mermaid-v13` | `707872c84de014f9e5e07e509d67dcd12f699fbda5db87170063cec91a187ac1` | `f41234eb33aa21d34df5b5097510c7d905eed17e34109c1a1df0a9a90f0e2508` |

## Observation rules fixed before browser use

- Mount each original SVG inline in an offline, white Chromium document with a 64 CSS-pixel gutter, a 1152 × 512 CSS-pixel viewport, DPR 1 and loaded host fonts. Retain its CSS and intrinsic size. Measure six distinct node-body pairs and the six combinations of a route and a node other than its source or destination in each artifact. Subgraph borders intentionally enclose nodes and the connecting route may cross those borders.
- Use the direct node rectangle and the identifiable, axis-aligned routed centerline in screen coordinates. Measure the Euclidean gap between their bounding rectangles. A positive gap proves disjointness, including for rounded corners. Report penetration only for an established intersection of interiors. Record boundary contact or unsupported geometry as indeterminate. Stroke thickness, arrowheads, shadows and edge-to-edge collisions are outside these two geometric assertions.
- Measure the SVG root against the host viewport. Record delivered glyph pixels by comparing a Chromium screenshot with the same layout after suppressing only glyph paint for the expected node and cluster labels. A nonzero difference establishes visible ink for that exact label. Allocate differing pixels to disjoint measured text ranges expanded by 6 CSS pixels. Preserve the per-label counts and any unassigned pixels.
- For clipping, repeat the visible/muted pair with rectangular overflow exposed on the root and label ancestors. Compare within the same capture, including a 16 CSS-pixel gutter around the SVG. Record ink recovered or changed, and any newly exposed diagram paint. Require stable text positions, distinct label regions and coverage of their bounds. A synthetic partly clipped label must recover ink under the same operation. Missing identities, unsupported clips/masks, unstable positions, uncovered pixels or a failed control limit the corresponding inference. The original screenshot supplies the preview.
- A matching reference only covers clipping that this intervention can expose at this size on this browser. These two selected inputs support per-artifact observations. Typography preferences, accessibility, other embeds and fonts, corpus-wide readability, pixel equivalence, renderer ranking and human review are outside the sample.

## Replay

Set `$archiveRoot` to the extracted directory containing `visual-sample` and `node-rounds`, and `$chrome` to your Chromium or Chrome executable. From the benchmark worktree with its installed `tools/mermaid-cli` dependencies, run the following PowerShell command once the timing window is clear. Choose a fresh output directory under `target` to preserve the published evidence. The browser profile is temporary and is created inside the output directory.

```powershell
$archiveRoot = '<path-to-extracted-raw-bundle>'
$chrome = '<path-to-chromium-executable>'
$sample = Join-Path $archiveRoot 'visual-sample'
$bundle = Join-Path $archiveRoot 'node-rounds'
node "$sample/observe.mjs" --worktree . --bundle $bundle --chrome $chrome --out './target/visual-sample-replay'
```

In `evidence.json`, bounds use `[left, top, right, bottom]` in host CSS pixels. Gap entries retain the node and edge IDs. Pixel counts refer to the original capture at DPR 1. Each PNG crops that capture to the exact root bounds plus the observation gutter, with integer rounding outwards.
