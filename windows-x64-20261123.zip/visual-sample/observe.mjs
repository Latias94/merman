// Replay six saved SVGs. No renderer or benchmark worker is invoked.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';

const here = path.dirname(fileURLToPath(import.meta.url));
const { values } = parseArgs({ options: Object.fromEntries(['bundle', 'worktree', 'chrome', 'out'].map(k => [k, { type: 'string' }])) });
const bundle = path.resolve(values.bundle ?? path.join(here, '../node-rounds'));
const out = path.resolve(values.out ?? here);
const tools = createRequire(path.resolve(values.worktree ?? '.', 'tools/mermaid-cli/package.json'));
const chrome = values.chrome ?? process.env.PUPPETEER_EXECUTABLE_PATH;
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const planHash = 'cfec188528d1ee06b8e58e38fbdd3a678c12040b9891f2420c8234056a43fa3c';
const engines = ['merman', 'pele', 'mermaid-v13'];
const cases = [
  { scenario: 'four-node-repeat', fixture: 'four-node-repeat-1', index: 6, request: 0, chain: ['A0','B0','C0','D0'],
    titles: [], sourceHash: '08cd16e84d5b2d8147724951612814609dda754c0ab175dcf2f7b56d6e7ee88b',
    hashes: ['4865cccf72fa9752029a7f3816c26304fe00af36f1142efebe82ef5c602e83d6','8142f97ecc1ab6a903f7a87feae23c86f7921d61e249e897ae4b117ec18f566a','707872c84de014f9e5e07e509d67dcd12f699fbda5db87170063cec91a187ac1'] },
  { scenario: 'merman-issue-guide', fixture: 'block-4', index: 11, request: 3, chain: ['L','T','S','P'],
    titles: ['CI','Deploy'], sourceHash: 'd4f6b38f11445ef7ef4f1c5618d22ca107e07a86ea02f5786f7c3550d33c8de1',
    hashes: ['4606091735a66ba75cd1cf987c61b5ffd26e569b694ab3b0fea42fd514bdebed','6863ab9fa51575a59bec050b9a3cf3191216278a9ef9f097ad11e9f936436a59','f41234eb33aa21d34df5b5097510c7d905eed17e34109c1a1df0a9a90f0e2508'] },
];
const planBytes = await readFile(path.join(bundle, 'plan.json'));
assert.equal(sha(planBytes), planHash);
const plan = JSON.parse(planBytes), jobs = [];
for (const c of cases) {
  const s = plan.scenarios[c.index], q = s.requests[c.request];
  assert.deepEqual([s.id, q.fixture, q.source_sha256, sha(q.source)], [c.scenario, c.fixture, c.sourceHash, c.sourceHash]);
  const labels = q.expected_labels.filter(t => !c.titles.includes(t));
  const expected = Object.fromEntries([...c.chain.map((id,i) => [id,labels[i]]), ...c.titles.map(t => [t,t])]);
  for (const [i, engine] of engines.entries()) {
    const round = 'rounds/001', worker = JSON.parse(await readFile(path.join(bundle, round, `${engine}.json`)));
    const scenario = worker.scenarios[c.index], occurrence = scenario.requests[c.request];
    const file = `${c.index}-${c.request}.svg`, sourcePath = `${round}/drawings/${engine}/${file}`;
    const bytes = await readFile(path.join(bundle, sourcePath)), result = scenario.warm_samples.at(-1).results[c.request];
    assert.deepEqual([worker.engine,worker.plan_sha256,scenario.id,occurrence.fixture,occurrence.diagram_id,occurrence.source_sha256,occurrence.drawing_artifact],
      [engine,planHash,s.id,q.fixture,q.diagram_id,c.sourceHash,file]);
    assert.deepEqual([result.status,result.output_bytes,result.output_sha256,sha(bytes)], ['ok',bytes.length,c.hashes[i],c.hashes[i]]);
    jobs.push({ svg: bytes.toString('utf8'), chain: c.chain, expected, record: { scenario: s.id, fixture: q.fixture, diagram_id: q.diagram_id,
      engine, package: `${worker.package.name}@${worker.package.version}`, source_sha256: c.sourceHash, svg: sourcePath, bytes: bytes.length, svg_sha256: sha(bytes) } });
  }
}

// These selectors describe only the two hash-pinned rectangular flowcharts.
function geometry({ chain, expected }) {
  const root = document.querySelector('main > svg');
  const rect = element => { const r = element.getBoundingClientRect(); return [r.left,r.top,r.right,r.bottom]; };
  const groups = [...root.querySelectorAll('g.node,g.pele-node,g.cluster,g.pele-cluster')];
  const requireOne = (items, label) => { if (items.length !== 1) throw Error(`Cannot identify ${label}`); return items[0]; };
  const owner = id => requireOne(groups.filter(g => g.dataset.id === id), id);
  const gap = (a,b) => Math.hypot(Math.max(0,a[0]-b[2],b[0]-a[2]), Math.max(0,a[1]-b[3],b[1]-a[3]));
  const shape = id => rect(requireOne([...owner(id).children].filter(e => e.localName === 'rect'), `rectangle ${id}`));
  const nodes = Object.fromEntries(chain.map(id => [id,shape(id)]));
  const pairs = [], routes = [], labels = {};
  for (const [i,id] of chain.entries()) {
    for (const other of chain.slice(i+1)) pairs.push({ nodes: [id,other], gap_css_px: gap(nodes[id],nodes[other]) });
    if (i === 0) continue;
    const from = chain[i-1], edge = `L_${from}_${id}_0`;
    const holder = requireOne([...root.querySelectorAll('[data-id]')].filter(e => e.dataset.id === edge),edge);
    const path = holder.localName === 'path' ? holder : requireOne([...holder.querySelectorAll(':scope > path:not(.marker,.pele-marker)')],edge);
    const box = rect(path), axis = box[0] === box[2] ? 'vertical' : box[1] === box[3] ? 'horizontal' : null;
    if (!axis || !(path.getTotalLength()>0) || getComputedStyle(path).stroke === 'none') throw Error(`Unsupported route ${edge}`);
    const tests = chain.filter(n => n !== from && n !== id).map(node => ({ node, gap_css_px: gap(box,nodes[node]) }));
    routes.push({ edge, axis, centerline_bounds_css: box, nonincident: tests });
  }
  for (const [id,word] of Object.entries(expected)) {
    const carrier = requireOne([...owner(id).querySelectorAll('text,foreignObject p')], `label ${id}`);
    if (carrier.textContent.trim() !== word || carrier.childNodes.length !== 1 || carrier.firstChild.nodeType !== 3) throw Error(`Unsupported label ${id}`);
    carrier.dataset.glyph = '';
    const clips = [], unsupported = [];
    for (let e=carrier; e && root.contains(e); e=e.parentElement) {
      const style = getComputedStyle(e);
      if (style.overflowX !== 'visible' || style.overflowY !== 'visible') clips.push(e.localName);
      if (style.clipPath !== 'none' || style.maskImage !== 'none' || style.clip !== 'auto' || style.filter !== 'none') unsupported.push(e.localName);
      e.dataset.openClip = '';
    }
    const range = document.createRange(); range.selectNodeContents(carrier.firstChild);
    const css = getComputedStyle(carrier);
    labels[id] = { text: word, kind: carrier.localName === 'text' ? 'svg-text' : 'foreignObject-html', range_css: rect(range),
      font_family_css: css.fontFamily, font_size_css: css.fontSize, overflow_ancestors: clips, unsupported_clip_mask_or_filter: unsupported };
  }
  return { root_css: rect(root), viewBox: root.getAttribute('viewBox'), nodes_css: nodes, node_pairs: pairs, routes, labels };
}

// Measure loss in the actual delivered composite, including HTML inside foreignObject.
async function compare({ images, clip, boxes, root }) {
  const frames = [];
  for (const png of images) {
    const bitmap = await createImageBitmap(new Blob([Uint8Array.from(atob(png),c=>c.charCodeAt(0))],{type:'image/png'}));
    if (bitmap.width !== clip.width || bitmap.height !== clip.height) throw Error('Capture dimensions changed');
    const ctx = new OffscreenCanvas(bitmap.width,bitmap.height).getContext('2d');
    ctx.drawImage(bitmap,0,0); bitmap.close();
    const data = ctx.getImageData(0,0,clip.width,clip.height).data;
    frames.push(new Uint32Array(data.buffer));
  }
  const [actual,muted,open,openMuted] = frames, labels = {};
  for (const id of Object.keys(boxes)) labels[id] = { visible_ink_px: 0, exposed_ink_px: 0, recovered_ink_px: 0, delivered_only_ink_px: 0, changed_shared_ink_px: 0 };
  let unassigned = 0, ambiguous = 0, changed = 0, outside = 0, revealed = 0;
  for (let i=0;i<actual.length;i++) {
    const x=clip.x+(i%clip.width)+0.5, y=clip.y+Math.floor(i/clip.width)+0.5;
    if (actual[i] !== open[i]) {
      changed++;
      if (x<root[0] || x>=root[2] || y<root[1] || y>=root[3]) outside++;
      if (actual[i]===0xffffffff && open[i]!==0xffffffff) revealed++;
    }
    const a=actual[i]!==muted[i], b=open[i]!==openMuted[i];
    if (!a && !b) continue;
    const owners = Object.entries(boxes).filter(([,r]) => x>=r[0]-6 && x<r[2]+6 && y>=r[1]-6 && y<r[3]+6);
    if (owners.length === 0) { unassigned++; continue; }
    if (owners.length > 1) { ambiguous++; continue; }
    const v = labels[owners[0][0]];
    v.visible_ink_px += Number(a); v.exposed_ink_px += Number(b);
    v.recovered_ink_px += Number(!a && b); v.delivered_only_ink_px += Number(a && !b);
    v.changed_shared_ink_px += Number(a && b && (actual[i]!==open[i] || muted[i]!==openMuted[i]));
  }
  return { labels, unassigned_ink_px: unassigned, ambiguous_ink_px: ambiguous, changed_on_open_px: changed,
    changed_outside_svg_on_open_px: outside, white_to_nonwhite_on_open_px: revealed };
}

const viewport = { width:1152, height:512, deviceScaleFactor:1 };
async function observe(page, job) {
  await page.evaluate(async svg => {
    document.body.className='';
    const doc = new DOMParser().parseFromString(svg,'image/svg+xml');
    if (doc.documentElement.localName!=='svg' || doc.querySelector('parsererror')) throw Error('Invalid input SVG');
    document.querySelector('main').replaceChildren(document.importNode(doc.documentElement,true));
    document.body.getBoundingClientRect(); await document.fonts.ready;
  },job.svg);
  const args = { chain:job.chain, expected:job.expected }, g = await page.evaluate(geometry,args);
  const [l,t,r,b]=g.root_css, x=Math.floor(l)-16, y=Math.floor(t)-16;
  const clip = { x,y,width:Math.ceil(r)+16-x,height:Math.ceil(b)+16-y };
  if (x<0 || y<0 || x+clip.width>viewport.width || y+clip.height>viewport.height) throw Error('SVG plus observation gutter extends outside the page');
  const images=[], ranges = v => Object.fromEntries(Object.entries(v.labels).map(([id,row])=>[id,row.range_css]));
  let stable=true;
  for (const state of ['', 'muted', 'open', 'open muted']) {
    await page.evaluate(state => {document.body.className=state;},state);
    const current = await page.evaluate(geometry,args);
    stable &&= JSON.stringify([current.root_css,ranges(current)]) === JSON.stringify([g.root_css,ranges(g)]);
    images.push(Buffer.from(await page.screenshot({clip,captureBeyondViewport:false})).toString('base64'));
  }
  const boxes=ranges(g);
  const covered=Object.values(boxes).every(q=>q[0]-6>=x && q[1]-6>=y && q[2]+6<=x+clip.width && q[3]+6<=y+clip.height);
  const pixels=await page.evaluate(compare,{images,clip,boxes,root:g.root_css});
  return { g, clip, stable, covered, pixels, preview:Buffer.from(images[0],'base64') };
}

assert.ok(chrome,'Supply --chrome PATH or PUPPETEER_EXECUTABLE_PATH');
const { default: puppeteer } = await import(pathToFileURL(tools.resolve('puppeteer-core')).href);
await mkdir(out,{recursive:true});
const base=await realpath(out), scratch=await mkdtemp(path.join(base,'.chromium-'));
const evidence = { schema_version:1, plan_sha256:planHash, round:'001', batch:'last warm batch', observer_sha256:sha(await readFile(fileURLToPath(import.meta.url))),
  protocol_sha256:sha(await readFile(path.join(here,'PROTOCOL.md'))), viewport_css:viewport, node:process.version, platform:process.platform, arch:process.arch,
  puppeteer_core:JSON.parse(await readFile(tools.resolve('puppeteer-core/package.json'))).version, results:[] };
let browser;
try {
  browser=await puppeteer.launch({executablePath:chrome,headless:true,userDataDir:path.join(scratch,'profile'),
    env:{...process.env,TEMP:scratch,TMP:scratch,TMPDIR:scratch},args:['--disable-background-networking','--disable-component-update','--disable-crash-reporter',`--crash-dumps-dir=${scratch}`]});
  const page=await browser.newPage(); await page.setOfflineMode(true); await page.setViewport(viewport);
  await page.setContent(`<meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'"><style>
    html,body{background:white}body{margin:64px}.muted [data-glyph]{fill:transparent!important;stroke:transparent!important;-webkit-text-fill-color:transparent!important;text-shadow:none!important}
    .open [data-open-clip]{overflow:visible!important}</style><main></main>`);
  evidence.browser=await browser.version(); evidence.locale=await page.evaluate(()=>navigator.language);
  const control=await observe(page,{chain:[],expected:{R:'Probe'},svg:'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="32" style="overflow:hidden"><g class="node" data-id="R"><text x="-6" y="21" font-family="Arial" font-size="16">Probe</text></g></svg>'});
  const probe=control.pixels.labels.R;
  const calibrated=control.stable && control.covered && !control.pixels.unassigned_ink_px && !control.pixels.ambiguous_ink_px && probe.visible_ink_px>0 && probe.recovered_ink_px>0;
  evidence.clipped_text_control={detected:calibrated, stable:control.stable, covered:control.covered, ...control.pixels};
  for (const job of jobs) {
    const { g,clip,stable,covered,pixels,preview }=await observe(page,job);
    const filename=`${job.record.engine}-${job.record.scenario}.png`;
    await writeFile(path.join(out,filename),preview);
    const valid=calibrated && stable && covered && pixels.unassigned_ink_px===0 && pixels.ambiguous_ink_px===0;
    for (const [id,label] of Object.entries(g.labels)) {
      const ink=pixels.labels[id]; Object.assign(label,ink);
      label.delivery=ink.visible_ink_px>0 && !pixels.ambiguous_ink_px ? 'visible ink' : 'indeterminate';
      label.clipping=!valid || label.unsupported_clip_mask_or_filter.length || !ink.exposed_ink_px ? 'indeterminate'
        : ink.recovered_ink_px ? 'ink recovered on opening overflow' : ink.changed_shared_ink_px || ink.delivered_only_ink_px ? 'paint changed on opening overflow' : 'no ink change on opening overflow';
    }
    delete pixels.labels;
    evidence.results.push({...job.record, preview:filename, preview_sha256:sha(preview), capture_css:clip, root_inside_viewport:true,
      node_pair_status:g.node_pairs.every(p=>p.gap_css_px>0)?'disjoint':'indeterminate contact or overlapping envelopes',
      nonincident_route_status:g.routes.every(e=>e.nonincident.every(p=>p.gap_css_px>0))?'disjoint':'indeterminate contact or intersecting envelopes',
      stable_text_and_root:stable, label_regions_inside_capture:covered, ...g, ...pixels});
  }
} finally {
  try { if (browser) { await browser.close(); console.log('Observation browser closed.'); } }
  finally { const dir=await realpath(scratch); assert.equal(path.dirname(dir),base); assert.ok(path.basename(dir).startsWith('.chromium-')); await rm(dir,{recursive:true,force:true,maxRetries:5,retryDelay:200}); }
}
await writeFile(path.join(out,'evidence.json'),JSON.stringify(evidence,null,2)+'\n');
console.log(`Wrote ${evidence.results.length} artifact observations.`);
